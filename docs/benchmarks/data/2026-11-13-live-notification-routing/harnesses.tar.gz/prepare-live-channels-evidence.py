from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile
ov=Path('/home/bart/src/.worktrees/omnivox/audio-device-selection')
ev=Path('/home/bart/src/.worktrees/emacsvox/audio-device-selection')
native=Path('/mnt/c/Users/bart/AppData/Local/Emacsvox/AudioDeviceTests/channels-20261113')
pack=ov/'docs/benchmarks/data/2026-11-13-live-notification-routing';pack.mkdir(parents=True,exist_ok=True)
def gz(name,data):
    with (pack/name).open('wb') as f:
        with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as g:g.write(data)
bases={ov:'66985e1',ev:'c3ca91971c3c31a2bce61956fefaba60550caeac'}
for repo,name,paths in [(ov,'omnivox-source.patch.gz',['omnivox-cli','omnivox-tts']),(ev,'emacsvox-source.patch.gz',['lisp','test'])]:
    gz(name,subprocess.check_output(['git','diff','--binary',bases[repo],'--',*paths],cwd=repo))
gz('windows-build-source.patch.gz',Path('/tmp/omnivox-live-channels-full-build.patch').read_bytes())
for name in ['PROVENANCE','SHA256SUMS']:
    shutil.copy2(ev/'servers/omnivox-bin/current'/name,pack/('runtime-'+name))
with tarfile.open(pack/'check-logs.tar.gz','w:gz') as tar:
    for pattern in ['omnivox-live-channels-*.log','emacsvox-live-channels-*.log']:
        for p in sorted(Path('/tmp').glob(pattern)):tar.add(p,arcname=p.name)
with tarfile.open(pack/'native-results.tar.gz','w:gz') as tar:
    for p in sorted((native/'logs').rglob('*')):
        if p.is_file() and not any(x in p.relative_to(native/'logs').parts for x in ['voices','state','profile']):
            tar.add(p,arcname=str(p.relative_to(native)))
    if (native/'handoff.json').exists():tar.add(native/'handoff.json',arcname='handoff.json')
with tarfile.open(pack/'harnesses.tar.gz','w:gz') as tar:
    for p in sorted(native.iterdir()):
        if p.suffix in ['.el','.ps1','.cs']:tar.add(p,arcname=p.name)
    tar.add('/tmp/run-live-channels-wsl.py',arcname='run-live-channels-wsl.py')
    tar.add('/tmp/prepare-live-channels-evidence.py',arcname='prepare-live-channels-evidence.py')
provenance={'date':'2026-11-13','kind':'functional-development-checks','omnivox_base':subprocess.check_output(['git','rev-parse',bases[ov]],cwd=ov,text=True).strip(),'emacsvox_base':subprocess.check_output(['git','rev-parse',bases[ev]],cwd=ev,text=True).strip(),'runtime':'287fd0119a8f77d0','rust':'1.97.1','native_emacs':'31.1','wsl_emacs':'31.0.90','native_candidate':str(native),'source_patch_scope':'Behavioral source and tests; generated manuals excluded','windows_build_patch_sha256':hashlib.sha256(Path('/tmp/omnivox-live-channels-full-build.patch').read_bytes()).hexdigest(),'commands':['cargo +1.97.1 test --locked --workspace','cargo +1.97.1 clippy --locked --workspace --all-targets -- -D warnings','cargo +1.97.1 clippy --locked --target x86_64-pc-windows-gnu -p omnivox-cli -p omnivox-tts -p omnivox-audio --all-targets -- -D warnings','make windows-omnivox-dev OMNIVOX_DIR=/home/bart/src/.worktrees/omnivox/audio-device-selection-build','make bytecode-rebuild EMACS=/home/bart/opt/emacs-31/bin/emacs','make graphical-menu-test EMACS=/home/bart/opt/emacs-31/bin/emacs TEST_DEPS_DIR=/home/bart/.cache/emacsvox/test-deps/menu-20261113-emacs-31.0.90 MENU_TEST_LOAD=compiled','make headers-check version-check docs-release-check EMACS=/home/bart/opt/emacs-31/bin/emacs','run-channel-check.ps1 -Engine eloquence','run-channel-check.ps1 -Engine dectalk','run-live-channels-wsl.py eloquence','run-live-channels-wsl.py dectalk','run-personal-check.ps1 -Engine eloquence','run-personal-check.ps1 -Engine dectalk'],'known_full_ert_failures':['emacsvox-aural-audit-current-tree-is-clean','emacsvox-launcher-rotates-omnivox-stderr-by-size','emacsvox-native-windows-guide-is-bounded-and-complete'],'limits':['No new acoustic listening acceptance','WSL harness does not inspect Windows child PIDs','Full ERT preceded final menu-helper wiring correction; compiled graphical and native personal checks cover final wiring','Initial native harness compared per-owner startup paths/hashes instead of acknowledged engine activation; failed results retained','First graphical run failed menu wiring, fixed and rerun','Native preflight rejected stale parent byte-code after menu edit; parents rebuilt']}
(pack/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
(pack/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(pack.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print(pack)
