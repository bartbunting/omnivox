$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:LOCALAPPDATA 'Emacsvox\AudioDeviceTests\channels-20261113'
$previous=Join-Path $env:LOCALAPPDATA 'Emacsvox\AudioDeviceTests\client-20261113\evox-windows-launcher.exe'
$desktop=[Environment]::GetFolderPath('Desktop')
$path=Join-Path $desktop 'Emacsvox Audio Devices.lnk'
$normal=Join-Path $desktop 'Emacsvox Windows.lnk'
$before=(Get-FileHash -LiteralPath $normal).Hash
$shell=New-Object -ComObject WScript.Shell
$shortcut=$shell.CreateShortcut($path)
if ($shortcut.TargetPath -ne $previous) { throw 'Audio Devices shortcut target changed; refusing to replace an unreviewed target.' }
foreach ($engine in @('eloquence','dectalk')) {
 $file=Get-ChildItem -LiteralPath (Join-Path $root 'logs') -Filter ("personal-$engine-*.json") | Sort-Object Name | Select-Object -Last 1
 $report=[IO.File]::ReadAllText($file.FullName) | ConvertFrom-Json
 if ($report.result -ne 'passed' -or $report.client_process_cleanup -ne 'retired' -or $report.engines.Count -ne 2 -or @($report.engines | Where-Object { $_ -ne $engine }).Count) { throw "Unqualified personal profile: $engine" }
}
$runtime=Join-Path $env:LOCALAPPDATA 'Emacsvox\Omnivox\runtime\287fd0119a8f77d0\omnivox.exe'
$remaining=@(Get-CimInstance Win32_Process -Filter "Name='omnivox.exe'" | Where-Object { $_.ExecutablePath -eq $runtime })
if ($remaining.Count) { throw 'Candidate test workers still exist; inspect cleanup.' }
$backup=Join-Path $root 'previous-audio-devices.lnk'
if (Test-Path -LiteralPath $backup) { throw 'Shortcut backup already exists.' }
Copy-Item -LiteralPath $path -Destination $backup
$shortcut.TargetPath=Join-Path $root 'evox-windows-launcher.exe'
$shortcut.WorkingDirectory=$root
$shortcut.Description='Emacsvox audio devices and live notification Left/Right/Both routing; Save is separate'
$shortcut.Save()
$readback=$shell.CreateShortcut($path)
if ($readback.TargetPath -ne $shortcut.TargetPath -or (Get-FileHash -LiteralPath $normal).Hash -ne $before) {
 Copy-Item -LiteralPath $backup -Destination $path -Force
 throw 'Shortcut verification failed; restored the previous candidate shortcut.'
}
$config=[IO.File]::ReadAllText((Join-Path $root 'client\native-install.json')) | ConvertFrom-Json
$report=[ordered]@{updated_utc=[DateTime]::UtcNow.ToString('o');shortcut=$path;previous_target=$previous;backup=$backup;target=$readback.TargetPath;
 runtime=$runtime;source_commit=$config.SourceCommit;normal_shortcut_sha256=$before.ToLower();normal_shortcut_unchanged=$true;candidate_test_processes=$remaining.Count;
 default_engine='eloquence';early_speech=$true;personal_configuration='Existing personal configuration; no saved channel or physical-output preferences changed by handoff';
 launcher_sha256=(Get-FileHash -LiteralPath $shortcut.TargetPath).Hash.ToLower();script_sha256=(Get-FileHash -LiteralPath (Join-Path $root 'evox-windows.ps1')).Hash.ToLower()}
$json=$report | ConvertTo-Json -Depth 5
[IO.File]::WriteAllText((Join-Path $root 'handoff.json'),$json,(New-Object Text.UTF8Encoding($false)))
Write-Output $json
