from pathlib import Path
import os,subprocess,datetime,shutil,sys
engine=sys.argv[1]
repo=Path('/home/bart/src/.worktrees/emacsvox/audio-device-selection')
root=Path('/mnt/c/Users/bart/AppData/Local/Emacsvox/AudioDeviceTests/channels-20261113')
run=root/'logs'/('wsl-'+engine+'-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
run.mkdir()
shutil.copy2('/mnt/c/Users/bart/AppData/Local/Emacsvox/NativeLightweight/merge-check-20261113/probe-config/config.json',run/'config.json')
def win(path):return subprocess.check_output(['wslpath','-w',str(path)],text=True).strip()
env=os.environ.copy()
for key in ['OMNIVOX_AUDIO_DEVICE','OMNIVOX_AUDIO_DEVICE_PREFERENCES','OMNIVOX_OWNED_AUDIO_DEVICE','OMNIVOX_OWNED_AUDIO_DEVICE_HOST','OMNIVOX_EXPERIMENTAL_EARLY_SPEECH','EMACSVOX_PLAY']:
    env.pop(key,None)
env.update(EMACSVOX_DIR=str(repo), TTS_PROGRAM=str(repo/'servers/omnivox'),OMNIVOX_PROGRAM='/mnt/c/Users/bart/AppData/Local/Emacsvox/Omnivox/runtime/287fd0119a8f77d0/omnivox.exe',
           OMNIVOX_CONFIG_DIR=win(run),OMNIVOX_VOICE_ROOT=win(run/'voices'),OMNIVOX_ENGINE=engine,OMNIVOX_AUDIO_OUTPUT='device',OMNIVOX_DEVICE_TEST_ROOT=str(run),
           ESPEAK_NG_DATA=(repo/'servers/omnivox-bin/current/espeak-ng-data.path').read_text().strip(),XDG_STATE_HOME=str(run/'state'))
print(run,flush=True)
with (run/'emacs.log').open('w') as log:
    result=subprocess.run(['/home/bart/opt/emacs-31/bin/emacs','-Q','--batch','-l',str(root/'channel-check.el')],env=env,cwd=repo,stdout=log,stderr=subprocess.STDOUT,timeout=360)
if (run/'result.json').exists(): print((run/'result.json').read_text())
raise SystemExit(result.returncode)
