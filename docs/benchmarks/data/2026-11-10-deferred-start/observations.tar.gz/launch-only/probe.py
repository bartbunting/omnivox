import base64
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

root = Path(__file__).resolve().parent
output = root / "run-1"
output.mkdir(exist_ok=False)
linux = Path("/home/bart/src/omnivox-lightweight-reload/target/emergency-speech/payload/omnivox")
windows = Path("/mnt/c/Users/bart/AppData/Local/Temp/omnivox-lightweight-20261110/Emacsvox/Omnivox/runtime/f5da2adc0cbd255f/omnivox.exe")
launcher = Path("/home/bart/src/emacsvox-lightweight-reload/servers/omnivox")
native_path = subprocess.check_output(["wslpath", "-w", str(windows)], text=True).strip()
env = {k: os.environ[k] for k in ("PATH", "HOME", "LANG", "WSL_INTEROP", "XDG_RUNTIME_DIR") if k in os.environ}
cases = [("linux-direct", linux, linux), ("linux-launcher", launcher, linux),
         ("wsl-windows-direct", windows, windows), ("wsl-windows-launcher", launcher, windows)]
rows = []
for block in range(25):
    offset = block % len(cases)
    for label, program, selected in cases[offset:] + cases[:offset]:
        start = time.perf_counter_ns()
        p = subprocess.run([str(program), "--emergency-version"],
                           env={**env, "OMNIVOX_PROGRAM": str(selected)}, capture_output=True, timeout=5)
        elapsed = (time.perf_counter_ns() - start) / 1e6
        assert p.returncode == 0 and p.stdout.strip() == b"OMNIVOX-EMERGENCY 1", (label, p)
        rows.append(dict(case=label, block=block, warmup=block == 0, ms=elapsed))
    (output / "wsl-rows.json").write_text(json.dumps(rows, indent=2) + "\n")

# One already-running native parent, excluding PowerShell's own WSL launch.
script = r'''
$ErrorActionPreference = 'Stop'
$exe = '__PATH__'
$rows = @()
for ($i = 0; $i -lt 25; $i++) {
  $info = New-Object System.Diagnostics.ProcessStartInfo
  $info.FileName = $exe
  $info.Arguments = '--emergency-version'
  $info.UseShellExecute = $false
  $info.RedirectStandardOutput = $true
  $info.RedirectStandardError = $true
  $info.CreateNoWindow = $true
  $timer = [System.Diagnostics.Stopwatch]::StartNew()
  $process = [System.Diagnostics.Process]::Start($info)
  $stdout = $process.StandardOutput.ReadToEnd()
  $stderr = $process.StandardError.ReadToEnd()
  $process.WaitForExit()
  $timer.Stop()
  if ($process.ExitCode -ne 0 -or $stdout.Trim() -ne 'OMNIVOX-EMERGENCY 1') { throw "probe failed: $stderr" }
  $rows += [pscustomobject]@{case='windows-native-parent'; block=$i; warmup=($i -eq 0); ms=$timer.Elapsed.TotalMilliseconds}
  $process.Dispose()
}
$rows | ConvertTo-Json
'''.replace("__PATH__", native_path.replace("'", "''"))
(output / "native-parent.ps1").write_text(script)
p = subprocess.run(["/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe",
                    "-NoProfile", "-NonInteractive", "-EncodedCommand",
                    base64.b64encode(script.encode("utf-16le")).decode()], capture_output=True, timeout=90)
(output / "native-parent.stdout").write_bytes(p.stdout)
(output / "native-parent.stderr").write_bytes(p.stderr)
assert p.returncode == 0, p.stderr.decode(errors="replace")
rows += json.loads(p.stdout.decode("utf-8-sig"))
(output / "all-rows.json").write_text(json.dumps(rows, indent=2) + "\n")
summary = {}
for label in dict.fromkeys(row['case'] for row in rows):
    values = [row['ms'] for row in rows if row['case'] == label and not row['warmup']]
    summary[label] = dict(n=len(values), minimum_ms=min(values), median_ms=statistics.median(values), maximum_ms=max(values))
(output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
(output / "provenance.json").write_text(json.dumps(dict(
    linux=str(linux), linux_sha256=hashlib.sha256(linux.read_bytes()).hexdigest(),
    windows=str(windows), windows_sha256=hashlib.sha256(windows.read_bytes()).hexdigest(),
    notes=["No engine, management host or audio initialization; --emergency-version exits first.",
           "24 measured samples per case plus one retained warmup; WSL cases rotated each block.",
           "Native-parent block runs afterward in one PowerShell/.NET parent; parent/API and order differ.",
           "Warm caches; background host load uncontrolled. No Defender, hashing or full restart attribution."]), indent=2) + "\n")
print(json.dumps(summary, indent=2))
