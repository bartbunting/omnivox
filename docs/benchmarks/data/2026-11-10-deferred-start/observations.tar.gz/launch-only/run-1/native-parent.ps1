
$ErrorActionPreference = 'Stop'
$exe = 'C:\Users\bart\AppData\Local\Temp\omnivox-lightweight-20261110\Emacsvox\Omnivox\runtime\f5da2adc0cbd255f\omnivox.exe'
$rows = @()
for ($i = 0; $i -lt 25; $i++) {
  $info = New-Object System.Diagnostics.ProcessStartInfo
  $info.FileName = $exe
  $info.Arguments = '--emergency-version'
  $info.UseShellExecute = $false
  $info.RedirectStandardOutput = $true
  $info.RedirectStandardError = $true
  $info.CreateNoWindow = $true
  $timer = [System.Diagnostics.Stopwatch]::StartNew()
  $process = [System.Diagnostics.Process]::Start($info)
  $stdout = $process.StandardOutput.ReadToEnd()
  $stderr = $process.StandardError.ReadToEnd()
  $process.WaitForExit()
  $timer.Stop()
  if ($process.ExitCode -ne 0 -or $stdout.Trim() -ne 'OMNIVOX-EMERGENCY 1') { throw "probe failed: $stderr" }
  $rows += [pscustomobject]@{case='windows-native-parent'; block=$i; warmup=($i -eq 0); ms=$timer.Elapsed.TotalMilliseconds}
  $process.Dispose()
}
$rows | ConvertTo-Json
