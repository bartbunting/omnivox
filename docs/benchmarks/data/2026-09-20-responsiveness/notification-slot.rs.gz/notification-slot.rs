
use std::sync::{mpsc,Arc,Mutex,Condvar};
use std::sync::atomic::{AtomicBool,AtomicU64,AtomicUsize,Ordering};
use std::thread;
use std::time::{Duration,Instant};
const MAX_ISOLATED_CALLS:usize=2;
const CANCELLATION_POLL_INTERVAL:Duration=Duration::from_millis(10);
const TRANSIENT_ENGINE_WAIT:Duration=Duration::from_millis(350);
macro_rules! warn { ($($args:tt)*) => {()} }
#[derive(Debug)] enum TtsError { NotAvailable }
struct SynthesisCancellationToken;
struct IsolatedTtsEngine { budget:Arc<IsolationBudget>, engine_active:Arc<AtomicBool> }
impl IsolatedTtsEngine {
 fn was_cancelled(&self,_:u64,_:u64,_:Option<&SynthesisCancellationToken>)->bool{false}
 fn cancellation_error(&self)->TtsError{TtsError::NotAvailable}
    fn acquire_for_current_generation(
        &self,
        engine_id: &str,
        generation: u64,
        stop_epoch: u64,
        cancellation: Option<&SynthesisCancellationToken>,
    ) -> Result<IsolationLease, TtsError> {
        let deadline = Instant::now() + TRANSIENT_ENGINE_WAIT;
        let mut availability = self.budget.availability.lock().unwrap();
        loop {
            let pressure = match self.budget.try_acquire(&self.engine_active) {
                Ok(lease) => return Ok(lease),
                Err(pressure) => pressure,
            };
            if self.was_cancelled(generation, stop_epoch, cancellation) {
                drop(availability);
                return Err(self.cancellation_error());
            }
            if Instant::now() >= deadline {
                drop(availability);
                match pressure {
                    IsolationPressure::EngineOccupied => warn!(
                        engine_id,
                        wait_ms = TRANSIENT_ENGINE_WAIT.as_millis(),
                        "Engine remained occupied after bounded wait; routing through fallback"
                    ),
                    IsolationPressure::ProcessLimit => warn!(
                        engine_id,
                        in_flight = self.budget.in_flight.load(Ordering::Acquire),
                        quarantined = self.budget.quarantined.load(Ordering::Acquire),
                        global_limit = MAX_ISOLATED_CALLS,
                        wait_ms = TRANSIENT_ENGINE_WAIT.as_millis(),
                        "Process-wide isolated synthesis capacity remained occupied; routing through fallback"
                    ),
                }
                return Err(TtsError::NotAvailable);
            }
            // Wake as soon as either this engine or the process budget is
            // released. The timeout still bounds cancellation observation when
            // a native call remains blocked; it is no longer a readiness delay.
            let remaining = deadline.saturating_duration_since(Instant::now());
            (availability, _) = self
                .budget
                .released
                .wait_timeout(availability, CANCELLATION_POLL_INTERVAL.min(remaining))
                .unwrap();
        }
    }
}
fn main(){
 let budget=Arc::new(IsolationBudget::new());
 let engine=IsolatedTtsEngine { budget:Arc::clone(&budget), engine_active:Arc::new(AtomicBool::new(false)) };
 for iteration in 0..120 {
  let lease=budget.try_acquire(&engine.engine_active).ok().unwrap();
  let (ready_tx,ready_rx)=mpsc::channel();
  let (released_tx,released_rx)=mpsc::channel();
  let worker=thread::spawn(move || {
   ready_tx.send(()).unwrap();
   thread::sleep(Duration::from_millis(2));
   let release=Instant::now();
   drop(lease);
   released_tx.send(release).unwrap();
  });
  ready_rx.recv().unwrap();
  let acquired=engine.acquire_for_current_generation("probe",0,0,None).unwrap();
  let now=Instant::now();
  let released=released_rx.recv().unwrap();
  if iteration>=20 {println!("{}",now.duration_since(released).as_nanos());}
  drop(acquired);worker.join().unwrap();
 }
}
pub struct IsolationBudget {
    in_flight: AtomicUsize,
    quarantined: AtomicUsize,
    availability: Mutex<()>,
    released: Condvar,
}

enum IsolationPressure {
    EngineOccupied,
    ProcessLimit,
}

impl IsolationBudget {
    pub fn new() -> Self {
        Self {
            in_flight: AtomicUsize::new(0),
            quarantined: AtomicUsize::new(0),
            availability: Mutex::new(()),
            released: Condvar::new(),
        }
    }

    fn try_acquire(
        self: &Arc<Self>,
        engine_active: &Arc<AtomicBool>,
    ) -> Result<IsolationLease, IsolationPressure> {
        if engine_active
            .compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)
            .is_err()
        {
            return Err(IsolationPressure::EngineOccupied);
        }

        let mut current = self.in_flight.load(Ordering::Acquire);
        loop {
            if current >= MAX_ISOLATED_CALLS {
                engine_active.store(false, Ordering::Release);
                return Err(IsolationPressure::ProcessLimit);
            }
            match self.in_flight.compare_exchange_weak(
                current,
                current + 1,
                Ordering::AcqRel,
                Ordering::Acquire,
            ) {
                Ok(_) => break,
                Err(observed) => current = observed,
            }
        }

        Ok(IsolationLease(Arc::new(IsolationLeaseInner {
            budget: Arc::clone(self),
            engine_active: Arc::clone(engine_active),
            quarantined: AtomicBool::new(false),
        })))
    }

    #[cfg(test)]
    fn in_flight(&self) -> usize {
        self.in_flight.load(Ordering::Acquire)
    }

    #[cfg(test)]
    fn quarantined(&self) -> usize {
        self.quarantined.load(Ordering::Acquire)
    }
}

impl Default for IsolationBudget {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Clone)]
struct IsolationLease(Arc<IsolationLeaseInner>);

impl IsolationLease {
    fn mark_quarantined(&self) {
        if !self.0.quarantined.swap(true, Ordering::AcqRel) {
            self.0.budget.quarantined.fetch_add(1, Ordering::AcqRel);
        }
    }
}

struct IsolationLeaseInner {
    budget: Arc<IsolationBudget>,
    engine_active: Arc<AtomicBool>,
    quarantined: AtomicBool,
}

impl Drop for IsolationLeaseInner {
    fn drop(&mut self) {
        // Pair slot publication with admission's check-and-wait lock so a
        // finishing native call cannot disappear between checking and sleeping.
        let _availability = self.budget.availability.lock().unwrap();
        if self.quarantined.load(Ordering::Acquire) {
            self.budget.quarantined.fetch_sub(1, Ordering::AcqRel);
        }
        self.budget.in_flight.fetch_sub(1, Ordering::AcqRel);
        self.engine_active.store(false, Ordering::Release);
        self.budget.released.notify_all();
    }
}

