from pathlib import Path
import sys, tempfile, subprocess, json, re, hashlib, zipfile
sys.path.insert(0, str(Path.cwd()/'tools'))
import verify_release as verify
assets=Path.cwd()/'target/published-1.18.0'
for archive in sorted(assets.glob('*.zip')):
    verify.verify_checksum(archive, assets/'sha256sums.txt')
    print('Checksum passed:',archive.name,archive.stat().st_size,flush=True)
for suffix,arch in [('x64','x86_64'),('arm64','aarch64')]:
    with tempfile.TemporaryDirectory(prefix='omnivox-1.18-layout-') as tmp:
        root=Path(tmp)
        verify.extract_archive(assets/f'omnivox-1.18.0-windows-{suffix}.zip',root,'windows')
        binary=verify.verify_layout(root,'windows','1.18.0',require_tgspeechbox=True)
        verify.verify_architecture(binary,'windows',arch)
        lock=(root/'third-party-licenses/omnivox-Cargo.lock').read_text()
        assert lock==Path('Cargo.lock').read_text()
        provenance=json.loads((root/'tgspeechbox/SOURCE-PROVENANCE.json').read_text())
        print('Layout, architecture, notices and Cargo.lock passed:',suffix,flush=True)
        print('TGSpeechBox provenance:',json.dumps(provenance,sort_keys=True),flush=True)
base=Path(tempfile.mkdtemp(prefix='omnivox-1.18-verify-',dir='/mnt/c/Users/bart/AppData/Local/Temp'))
root=base/'Extracted release with spaces';root.mkdir()
work=base/'Unrelated working directory';work.mkdir()
config=base/'Empty configuration';config.mkdir()
verify.extract_archive(assets/'omnivox-1.18.0-windows-x64.zip',root,'windows')
binary=root/'omnivox.exe'
def native_path(path):return subprocess.check_output(['wslpath','-w',str(path)],text=True).strip()
def run(args):return verify.run([str(binary),'--config-dir',native_path(config),*args],work,verify.clean_environment())
assert run(['--version']).strip()=='omnivox 1.18.0'
for engine in ('espeak','native','tgspeechbox'):
    voices=run(['--engine',engine,'--list-voices'])
    count=re.search(r'Found\s+(\d+)\s+voices',voices); assert count and int(count[1])>0
    output=work/f'{engine}-release-probe.wav'
    run(['--engine',engine,'--dump-wav','',native_path(output),'Omnivox release verification.'])
    verify.read_wav(output,canonical=True)
    verify.read_wav(output.with_name(output.stem+'_raw.wav'),canonical=False)
    print('Native Windows synthesis passed:',engine,'voices:',count[1], 'WAV bytes:',output.stat().st_size,flush=True)
subprocess.run([sys.executable,'tools/test_windows_helper_startup.py','--helpers',str(root)],check=True,timeout=90)
Path('/tmp/omnivox-1.18-windows-validation-path').write_text(str(base)+'\n')
print('Retained Windows validation payload:',base,flush=True)
