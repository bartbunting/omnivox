param([string]$Runtime)
$ErrorActionPreference='Stop'
# Operator cleanup of this private test payload only, after all its probes ended.
# This supplies no product retirement receipt or permission to release assets.
$held=New-Object Collections.Generic.List[object]
foreach($row in @(Get-CimInstance Win32_Process | Where-Object {$_.ExecutablePath -and $_.ExecutablePath.Replace('\\?\','').StartsWith($Runtime+'\')})){
 $p=[Diagnostics.Process]::GetProcessById($row.ProcessId);$null=$p.Handle
 if($p.MainModule.FileName.Replace('\\?\','') -ne $row.ExecutablePath.Replace('\\?\','') -or [Math]::Abs(($p.StartTime-$row.CreationDate).TotalMilliseconds) -gt 2){throw 'Fixture identity changed'}
 $held.Add($p)
 [pscustomobject]@{pid=$p.Id;start=$p.StartTime;image=$p.MainModule.FileName} | ConvertTo-Json -Compress
}
foreach($p in $held){if(-not $p.HasExited){try{$p.Kill()}catch{if(-not $p.WaitForExit(2000)){throw}}}}
foreach($p in $held){if(-not $p.WaitForExit(6000)){throw 'Fixture did not exit'}}
