$ErrorActionPreference='Stop'
$os=Get-CimInstance Win32_OperatingSystem
$private=@(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -like '*\Temp\omnivox-handoff-20261110\*' -or $_.ExecutablePath -like '*\Temp\omnivox-lightweight-20261110\Emacsvox\Omnivox\runtime\c56e4a39e052332a\*' })
[ordered]@{os=$os.Caption;version=$os.Version;build=$os.BuildNumber;private_processes=@($private | Select-Object Name,ProcessId,ExecutablePath,CommandLine)} | ConvertTo-Json -Depth 4
