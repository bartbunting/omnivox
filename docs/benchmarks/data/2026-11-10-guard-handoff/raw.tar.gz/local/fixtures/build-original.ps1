param([string]$Source,[string]$Output)
$ErrorActionPreference='Stop'
if(Test-Path $Output){throw 'Fresh probe executable required'}
Add-Type -Path $Source -OutputAssembly $Output -OutputType ConsoleApplication -ReferencedAssemblies 'System.dll','System.Core.dll','System.Web.Extensions.dll' -CompilerParameters (New-Object CodeDom.Compiler.CompilerParameters -Property @{CompilerOptions='/platform:x64 /optimize+'})
