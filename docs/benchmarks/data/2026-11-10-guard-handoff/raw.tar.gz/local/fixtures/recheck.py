"""Bounded follow-up after the preliminary unexplained client exit, not timing evidence."""
from pathlib import Path
import os,subprocess,sys
base=Path('target/guard-handoff');root=Path('/mnt/c/Users/bart/AppData/Local/Temp/omnivox-handoff-20261110')
exe=Path('/mnt/c/Users/bart/AppData/Local/Temp/omnivox-lightweight-20261110/Emacsvox/Omnivox/runtime/c56e4a39e052332a/omnivox.exe')
env=os.environ.copy();env['OMNIVOX_TEST_BYTECODE']='1';env['OMNIVOX_TEST_WINDOWS_DATA']=r'C:\Users\bart\AppData\Local\Temp\omnivox-lightweight-20261110\Emacsvox\Omnivox\espeak-data\9a2e176369cfe0b982737abf6c26037f21d2b9af2a2fabcc08062864d0157718'
for n,variant in enumerate(['baseline','candidate','candidate','baseline']):
 with (base/f'recheck-{n}-{variant}.log').open('wb') as log:
  r=subprocess.run([sys.executable,str(base/'fixtures/client.py'),str(exe),str(root/f'recheck-{n}-{variant}')]+(['--legacy'] if variant=='baseline' else []),env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
 print(n,variant,r.returncode,flush=True)
 if r.returncode:raise SystemExit('repeat failure; retain and inspect exit status')
