"""Summaries of retained observations; no percentile/tail claims."""
from pathlib import Path
import collections,json,statistics
base=Path('target/guard-handoff');win=Path('/mnt/c/Users/bart/AppData/Local/Temp/omnivox-handoff-20261110')
result={'native':{},'client':{}}
native=json.loads((win/'result-12.json').read_text())
for case in sorted({r['case'] for r in native}):
 rows=[r for r in native if r['case']==case]; times=[r['retire_ms'] for r in rows]
 result['native'][case]={'n':len(rows),'all_passed':all(r['passed'] for r in rows),'empty_before_handle_cases':sum(r['empty_before_handles']>0 for r in rows),'retire_median_ms':statistics.median(times),'retire_range_ms':[min(times),max(times)],'pcm':sorted({r['pcm'] for r in rows if r['pcm']})}
for platform,root in [('windows',win),('linux',base)]:
 result['client'][platform]={}
 for variant in ['baseline','candidate']:
  samples=[];runmed=[];prep=[];bridge=[];gap=[];cases=collections.defaultdict(list)
  for block in range(4):
   folder=root/f'client-matched2-{platform}-{block}-{variant}';operations=json.loads((folder/'profile.json').read_text())['operations'];rows=json.loads((folder/'result.json').read_text());ops=[x for x in operations if x['success']]
   assert len(ops)==len(rows)==5
   runmed.append(statistics.median(x['ms'] for x in ops));samples.extend(x['ms'] for x in ops)
   for row in rows:cases[row['case']].append(row)
   for op in ops:
    prep.extend(s['ms'] for s in op['spans'] if s['function']=='omnivox-library--prepare-emergency')
    bridge.extend(s['ms'] for s in op['spans'] if s['function']=='omnivox-native-guard--connect')
   op,row=ops[2],rows[2];assert row['case']=='repeated'
   retire=next(s for s in op['spans'] if s['function']=='omnivox-library--retire-for-emergency' and s['depth']==0)
   gap.append(op['ms']-retire['start_ms']+row['source_ms']-row['ready_ms'])
  result['client'][platform][variant]={'successful_calls':len(samples),'operation_median_ms':statistics.median(samples),'run_medians_ms':runmed,'preparation_median_ms':statistics.median(prep),'attach_median_ms':statistics.median(bridge),'healthy_source_gap_bounds_ms':gap,'full_case_ready_medians_ms':{k:statistics.median(x['ready_ms'] for x in v) for k,v in cases.items()}}
(base/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
