param([string]$Source,[string]$Output)
$ErrorActionPreference='Stop'
if(Test-Path $Output){throw 'Fresh probe executable required'}
$parameters=New-Object CodeDom.Compiler.CompilerParameters
$parameters.GenerateExecutable=$true
$parameters.OutputAssembly=$Output
$parameters.CompilerOptions='/platform:x64 /optimize+'
foreach($assembly in @('System.dll','System.Core.dll','System.Web.Extensions.dll')){$null=$parameters.ReferencedAssemblies.Add($assembly)}
Add-Type -Path $Source -CompilerParameters $parameters
