// Isolated native fixture; no Omnivox product implementation. SPDX-License-Identifier: MIT
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <fcntl.h>
static void fail(const char *why) { fprintf(stderr,"FAIL %s (%lu)\n",why,GetLastError());exit(2); }
static char line[1024*1024];
int main(int argc,char **argv) {
 if(argc>1 && strcmp(argv[1],"--idle")==0){Sleep(INFINITE);return 0;}
 setvbuf(stdout,NULL,_IONBF,0);puts("READY");
 if(!fgets(line,sizeof(line),stdin))fail("command");
 if(strncmp(line,"CHILD",5)==0){STARTUPINFOA si={0};PROCESS_INFORMATION pi={0};si.cb=sizeof(si);char cmd[4096];snprintf(cmd,sizeof(cmd),"\"%s\" --idle",argv[0]);
  if(CreateProcessA(argv[0],cmd,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&si,&pi)){puts("CHILD_ALLOWED");WaitForSingleObject(pi.hProcess,INFINITE);CloseHandle(pi.hThread);CloseHandle(pi.hProcess);}else printf("CHILD_BLOCKED %lu\n",GetLastError());Sleep(INFINITE);return 0;}
 unsigned long long in,out;if(sscanf(line,"ADOPT %llu %llu",&in,&out)!=2)fail("handles");
 if(argc>2){Sleep(INFINITE);return 0;}
 FILE *input=_fdopen(_open_osfhandle((intptr_t)in,_O_WRONLY|_O_BINARY),"wb");FILE *output=_fdopen(_open_osfhandle((intptr_t)out,_O_RDONLY|_O_BINARY),"rb");if(!input||!output)fail("adopt");
 setvbuf(input,NULL,_IONBF,0);puts("ACK");if(!fgets(line,sizeof(line),stdin)||strcmp(line,"GO\n"))fail("release");
 fputs("{\"protocol_version\":5,\"request_id\":1,\"type\":\"hello\",\"supported_protocol_versions\":[5]}\n",input);
 if(!fgets(line,sizeof(line),output)||!strstr(line,"\"hello\""))fail("hello");
 fputs("{\"protocol_version\":5,\"request_id\":2,\"type\":\"synthesize\",\"text\":\"Direct helper speech works.\",\"settings\":{\"voice_id\":null,\"rate\":0.5,\"pitch\":1,\"volume\":1}}\n",input);
 int chunks=0;for(;;){if(!fgets(line,sizeof(line),output))fail("frame");if(strstr(line,"\"type\":\"error\"")){fputs(line,stderr);fail("native helper");}if(strstr(line,"\"type\":\"audio_chunk\"")&&strstr(line,"data_base64"))chunks++;if(strstr(line,"\"type\":\"synthesis_completed\""))break;}
 if(!chunks){fail("empty PCM");}
 printf("PCM_CHUNKS %d\n",chunks);Sleep(INFINITE);return 0;
}
