// Isolated Windows creation/handle-handoff experiment. No installed speech.
// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Microsoft.Win32.SafeHandles;

public static class HandoffProbe {
 [StructLayout(LayoutKind.Sequential)] struct SI {
  public uint cb; public IntPtr reserved,desktop,title;
  public uint x,y,cx,cy,charsX,charsY,fill,flags;
  public ushort show,reservedSize; public IntPtr reservedBytes,input,output,error;
 }
 [StructLayout(LayoutKind.Sequential)] struct SX { public SI si; public IntPtr attrs; }
 [StructLayout(LayoutKind.Sequential)] struct PI { public IntPtr process,thread; public uint pid,tid; }
 [StructLayout(LayoutKind.Sequential)] struct Limits {
  public long processTime,jobTime; public uint flags;
  public UIntPtr minWorking,maxWorking; public uint active;
  public UIntPtr affinity; public uint priority,scheduling;
  public ulong readOps,writeOps,otherOps,readBytes,writeBytes,otherBytes;
  public UIntPtr processMemory,jobMemory,peakProcess,peakJob;
 }
 [StructLayout(LayoutKind.Sequential)] struct Accounting {
  public long user,kernel,periodUser,periodKernel;
  public uint faults,total,active,limited;
 }
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool CreatePipe(out IntPtr read,out IntPtr write,IntPtr security,uint size);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool CloseHandle(IntPtr handle);
 [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool DuplicateHandle(IntPtr source,IntPtr handle,IntPtr target,out IntPtr output,uint access,bool inherit,uint options);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool InitializeProcThreadAttributeList(IntPtr list,int count,int flags,ref IntPtr bytes);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool UpdateProcThreadAttribute(IntPtr list,uint flags,IntPtr attribute,IntPtr value,IntPtr bytes,IntPtr previous,IntPtr returned);
 [DllImport("kernel32.dll")] static extern void DeleteProcThreadAttributeList(IntPtr list);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CreateProcessW(string exe,StringBuilder args,IntPtr processSecurity,IntPtr threadSecurity,bool inherit,uint flags,IntPtr environment,string directory,ref SX startup,out PI process);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CreateJobObjectW(IntPtr security,string name);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetInformationJobObject(IntPtr job,int kind,ref Limits limits,uint size);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool QueryInformationJobObject(IntPtr job,int kind,out Accounting value,uint size,IntPtr returned);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateJobObject(IntPtr job,uint code);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateProcess(IntPtr process,uint code);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint ResumeThread(IntPtr thread);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(IntPtr handle,uint timeout);
 [DllImport("ntdll.dll")] static extern int NtSuspendProcess(IntPtr handle);
 static void Check(bool ok) { if(!ok)throw new Win32Exception(Marshal.GetLastWin32Error()); }
 static void Require(bool ok,string message) { if(!ok)throw new Exception(message); }
 static bool Ended(IntPtr handle) { uint result=WaitForSingleObject(handle,0);if(result==0)return true;if(result==258)return false;throw new Win32Exception(Marshal.GetLastWin32Error()); }
 static void Kill(IntPtr handle) { if(!Ended(handle)&&!TerminateProcess(handle,1)&&!Ended(handle))throw new Win32Exception(Marshal.GetLastWin32Error()); }
 static IntPtr Copy(IntPtr value,IntPtr target,bool inherit) { IntPtr result;Check(DuplicateHandle(GetCurrentProcess(),value,target,out result,0,inherit,2));return result; }
 static FileStream File(IntPtr handle,FileAccess access) { return new FileStream(new SafeFileHandle(handle,true),access,4096,false); }
 static string Read(StreamReader reader) { var t=reader.ReadLineAsync();if(!t.Wait(6000))throw new TimeoutException("bounded fixture reply");if(t.Result==null)throw new EndOfStreamException();return t.Result; }
 static string Quote(string value) { Require(value.IndexOf('"')<0,"literal test path only");return "\""+value+"\""; }
 sealed class Member : IDisposable {
  public IntPtr Process,Thread; public FileStream Input,Output; public bool Resumed;
  public void Resume() {Require(!Resumed,"duplicate release");Check(ResumeThread(Thread)!=uint.MaxValue);Resumed=true;}
  public void CloseIo() {if(Input!=null){Input.Dispose();Input=null;}if(Output!=null){Output.Dispose();Output=null;}}
  public void Dispose() {CloseIo();if(Thread!=IntPtr.Zero){CloseHandle(Thread);Thread=IntPtr.Zero;}if(Process!=IntPtr.Zero){Kill(Process);Require(WaitForSingleObject(Process,6000)==0,"retained fixture member survived cleanup");CloseHandle(Process);Process=IntPtr.Zero;}}
 }
 sealed class Owner : IDisposable {
  public IntPtr Job; public List<Member> Members=new List<Member>(); public bool Sealed;
  public Owner() {Job=CreateJobObjectW(IntPtr.Zero,null);Check(Job!=IntPtr.Zero);var l=new Limits();l.flags=0x2000;Check(SetInformationJobObject(Job,9,ref l,(uint)Marshal.SizeOf(typeof(Limits))));}
  public Accounting Count() {Accounting a;Check(QueryInformationJobObject(Job,1,out a,(uint)Marshal.SizeOf(typeof(Accounting)),IntPtr.Zero));return a;}
  public Member Spawn(string executable,string arguments,bool childRestricted) {
   Require(!Sealed && Members.Count<4,"creation closed or bound reached");
   IntPtr inputRead,inputWrite,outputRead,outputWrite;
   Check(CreatePipe(out inputRead,out inputWrite,IntPtr.Zero,4096));
   Check(CreatePipe(out outputRead,out outputWrite,IntPtr.Zero,4096));
   var copied=new List<IntPtr>();IntPtr attrs=IntPtr.Zero,handles=IntPtr.Zero,jobs=IntPtr.Zero,policy=IntPtr.Zero;
   bool initialized=false;PI pi=new PI();
   try {
    copied.Add(Copy(inputRead,GetCurrentProcess(),true));copied.Add(Copy(outputWrite,GetCurrentProcess(),true));
    IntPtr size=IntPtr.Zero;InitializeProcThreadAttributeList(IntPtr.Zero,childRestricted?3:2,0,ref size);
    attrs=Marshal.AllocHGlobal(size);Check(InitializeProcThreadAttributeList(attrs,childRestricted?3:2,0,ref size));initialized=true;
    handles=Marshal.AllocHGlobal(2*IntPtr.Size);Marshal.Copy(copied.ToArray(),0,handles,2);
    Check(UpdateProcThreadAttribute(attrs,0,(IntPtr)0x20002,handles,(IntPtr)(2*IntPtr.Size),IntPtr.Zero,IntPtr.Zero));
    jobs=Marshal.AllocHGlobal(IntPtr.Size);Marshal.WriteIntPtr(jobs,Job);
    Check(UpdateProcThreadAttribute(attrs,0,(IntPtr)0x2000d,jobs,(IntPtr)IntPtr.Size,IntPtr.Zero,IntPtr.Zero));
    if(childRestricted){policy=Marshal.AllocHGlobal(4);Marshal.WriteInt32(policy,1);Check(UpdateProcThreadAttribute(attrs,0,(IntPtr)0x2000e,policy,(IntPtr)4,IntPtr.Zero,IntPtr.Zero));}
    var start=new SX();start.si.cb=(uint)Marshal.SizeOf(typeof(SX));start.si.flags=0x100;start.si.input=copied[0];start.si.output=copied[1];start.si.error=copied[1];start.attrs=attrs;
    Check(CreateProcessW(executable,new StringBuilder(Quote(executable)+" "+arguments),IntPtr.Zero,IntPtr.Zero,true,0x08080404,IntPtr.Zero,Path.GetDirectoryName(executable),ref start,out pi));
    // Creation atomically joins the private job. The primary thread remains
    // suspended; ownership is stored before callers can acknowledge or resume.
    var member=new Member();member.Process=pi.process;member.Thread=pi.thread;
    member.Input=File(inputWrite,FileAccess.Write);inputWrite=IntPtr.Zero;
    member.Output=File(outputRead,FileAccess.Read);outputRead=IntPtr.Zero;
    Members.Add(member);pi.process=IntPtr.Zero;pi.thread=IntPtr.Zero;return member;
   } finally {
    if(initialized)DeleteProcThreadAttributeList(attrs);
    foreach(var p in new[]{attrs,handles,jobs,policy})if(p!=IntPtr.Zero)Marshal.FreeHGlobal(p);
    foreach(var h in copied)CloseHandle(h);
    foreach(var h in new[]{inputRead,inputWrite,outputRead,outputWrite})if(h!=IntPtr.Zero)CloseHandle(h);
    if(pi.process!=IntPtr.Zero){Kill(pi.process);WaitForSingleObject(pi.process,6000);CloseHandle(pi.process);}if(pi.thread!=IntPtr.Zero)CloseHandle(pi.thread);
   }
  }
  public Dictionary<string,object> Retire(int accounted) {
   Sealed=true;var timer=Stopwatch.StartNew();Check(TerminateJobObject(Job,1));
   foreach(var m in Members)m.CloseIo();
   int premature=0;var deadline=Stopwatch.StartNew();
   while(true){var a=Count();bool all=true;foreach(var m in Members)all&=Ended(m.Process);
    if(a.active==0&&!all)premature++;
    if(all&&a.active==0)return new Dictionary<string,object>{{"complete",a.total==accounted},{"total",a.total},{"retained",accounted},{"retire_ms",timer.Elapsed.TotalMilliseconds},{"empty_before_handles",premature}};
    if(deadline.ElapsedMilliseconds>6000)throw new TimeoutException("native completion absent");
    Thread.Yield();
   }
  }
  public void Dispose(){if(Job!=IntPtr.Zero){TerminateJobObject(Job,1);foreach(var m in Members)m.Dispose();CloseHandle(Job);Job=IntPtr.Zero;}}
 }
 static void Worker(bool loseAck) {
  Console.WriteLine("READY");Console.Out.Flush();
  string line=Console.ReadLine();if(line=="CHILD") {
   try {using(var child=Process.Start(new ProcessStartInfo(Environment.GetCommandLineArgs()[0],"--idle"){UseShellExecute=false,CreateNoWindow=true})){Console.WriteLine("CHILD_ALLOWED");Console.Out.Flush();child.WaitForExit();}}
   catch(Win32Exception e){Console.WriteLine("CHILD_BLOCKED "+e.NativeErrorCode);Console.Out.Flush();}Thread.Sleep(Timeout.Infinite);return;
  }
  string[] h=line.Split(' ');Require(h.Length==3&&h[0]=="ADOPT","bounded test handoff");
  using(var input=File(new IntPtr(long.Parse(h[1])),FileAccess.Write))
  using(var output=File(new IntPtr(long.Parse(h[2])),FileAccess.Read))
  using(var writer=new StreamWriter(input,new UTF8Encoding(false),4096,true))
  using(var reader=new StreamReader(output,Encoding.UTF8,false,4096,true)) {
   if(loseAck){Thread.Sleep(Timeout.Infinite);return;}
   Console.WriteLine("ACK");Console.Out.Flush();Require(Console.ReadLine()=="GO","no native release before acknowledgement");
   writer.AutoFlush=true;writer.WriteLine("{\"protocol_version\":5,\"request_id\":1,\"type\":\"hello\",\"supported_protocol_versions\":[5]}");
   var json=new JavaScriptSerializer();var hello=json.Deserialize<Dictionary<string,object>>(Read(reader));Require((string)hello["type"]=="hello","real helper hello");
   writer.WriteLine("{\"protocol_version\":5,\"request_id\":2,\"type\":\"synthesize\",\"text\":\"Direct helper speech works.\",\"settings\":{\"voice_id\":null,\"rate\":0.5,\"pitch\":1,\"volume\":1}}");
   int pcm=0;while(true){var frame=json.Deserialize<Dictionary<string,object>>(Read(reader));string type=(string)frame["type"];
    if(type=="audio_chunk")pcm+=Convert.FromBase64String((string)((Dictionary<string,object>)frame["chunk"])["data_base64"]).Length;
    if(type=="error")throw new Exception(json.Serialize(frame));if(type=="synthesis_completed")break;
   }
   Require(pcm>0,"real nonempty PCM");Console.WriteLine("PCM "+pcm);Console.Out.Flush();Thread.Sleep(Timeout.Infinite);
  }
 }
 public static int Main(string[] args) {
  try {
   if(args[0]=="--worker"){Worker(args.Length>1);return 0;}if(args[0]=="--idle"){Thread.Sleep(Timeout.Infinite);return 0;}
   string self=System.Reflection.Assembly.GetExecutingAssembly().Location,helper=args[0],destination=args[1];
   Require(!System.IO.File.Exists(destination),"fresh evidence file required");var results=new List<object>();var json=new JavaScriptSerializer();
   foreach(string mode in new[]{"before-create","before-duplicate","partial-duplicate","lost-ack","before-release","running","helper-survives-worker","child-restricted","unregistered-member"}) {
    for(int trial=0;trial<12;trial++)using(var owner=new Owner()) {
     var worker=owner.Spawn(self,"--worker"+(mode=="lost-ack"?" lost":""),true);worker.Resume();
     var input=new StreamWriter(worker.Input,new UTF8Encoding(false),4096,true);input.AutoFlush=true;
     var output=new StreamReader(worker.Output,Encoding.UTF8,false,4096,true);Require(Read(output)=="READY","worker started");
     Member native=null;string pcm=null;
     if(mode=="before-create") {Kill(worker.Process);Require(WaitForSingleObject(worker.Process,6000)==0,"worker exit");}
     else if(mode=="child-restricted") {input.WriteLine("CHILD");Require(Read(output).StartsWith("CHILD_BLOCKED "),"unregistered child was allowed");}
     else {
      native=owner.Spawn(helper,"",true);
      Require(!native.Resumed && owner.Count().total==2,"owned before initialization");
      if(mode=="before-duplicate")Kill(worker.Process);
      else {
       IntPtr write=Copy(native.Input.SafeFileHandle.DangerousGetHandle(),worker.Process,false);
       if(mode=="partial-duplicate")Kill(worker.Process);
       else {
        IntPtr read=Copy(native.Output.SafeFileHandle.DangerousGetHandle(),worker.Process,false);
        input.WriteLine("ADOPT "+write.ToInt64()+" "+read.ToInt64());native.CloseIo();
        if(mode=="lost-ack")Kill(worker.Process);
        else {
         Require(Read(output)=="ACK","actual handoff acknowledgement");
         if(mode=="before-release")Kill(worker.Process);
         else {
          native.Resume();input.WriteLine("GO");pcm=Read(output);Require(pcm.StartsWith("PCM "),pcm);
          if(mode=="helper-survives-worker"){Require(NtSuspendProcess(native.Process)==0,"pause helper");Kill(worker.Process);Require(WaitForSingleObject(worker.Process,6000)==0&&!Ended(native.Process),"surviving actual helper");}
          if(mode=="unregistered-member"){var extra=owner.Spawn(self,"--idle",true);extra.Resume();}
         }
        }
       }
      }
     }
     int accounted=mode=="before-create"||mode=="child-restricted"?1:2;
     var result=owner.Retire(accounted);Require((bool)result["complete"]==(mode!="unregistered-member"),"false proof or missing known completion");
     result["case"]=mode;result["trial"]=trial;result["pcm"]=pcm;result["passed"]=true;results.Add(result);
     System.IO.File.WriteAllText(destination,json.Serialize(results),new UTF8Encoding(false));
    }
    Console.WriteLine("PASS "+mode);
   }
   return 0;
  }catch(Exception e){Console.Error.WriteLine(e);return 1;}
 }
}
