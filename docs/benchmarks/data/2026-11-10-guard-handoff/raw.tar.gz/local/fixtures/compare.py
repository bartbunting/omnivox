"""Matched client-only recovery comparison; Windows uses the unqualified frozen prototype."""
import json,os,subprocess,sys
from pathlib import Path
base=Path('target/guard-handoff'); native=Path('/mnt/c/Users/bart/AppData/Local/Temp/omnivox-handoff-20261110')
win=json.loads(Path('target/guard-windows/runtime.json').read_text())
env=os.environ.copy();env['OMNIVOX_TEST_BYTECODE']='1';env['OMNIVOX_TEST_WINDOWS_DATA']=r'C:\Users\bart\AppData\Local\Temp\omnivox-lightweight-20261110\Emacsvox\Omnivox\espeak-data\9a2e176369cfe0b982737abf6c26037f21d2b9af2a2fabcc08062864d0157718'
for platform,exe,root in [('windows',Path(win['runtime'])/'omnivox.exe',native),('linux',Path('target/guard-windows/linux-final-payload-2/omnivox'),base)]:
 for block in range(4):
  for variant in (['baseline','candidate'] if block%2==0 else ['candidate','baseline']):
   folder=root/f'client-matched2-{platform}-{block}-{variant}'
   command=[sys.executable,str(base/'fixtures/client.py'),str(exe),str(folder),'--profile']+(['--legacy'] if variant=='baseline' else [])
   with (base/f'client-matched2-{platform}-{block}-{variant}.log').open('wb') as log:
    r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
   print(platform,block,variant,r.returncode,flush=True)
   if r.returncode:raise SystemExit('failed; inspect preserved log')
