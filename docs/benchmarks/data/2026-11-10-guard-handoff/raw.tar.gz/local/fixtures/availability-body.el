(require 'omnivox-preferences)
(let (records)
  (unwind-protect
      (progn
        (tts-initialize)
        (emergency-test--speech "flite")
        (let ((old tts-speaker-process) (peer tts-notify-process))
          (dotimes (trial 4)
            (let ((pending (make-hash-table :test #'eq)) samples reloads failures timer prepared begin end)
              (unwind-protect
                  (progn
                    (setq begin (float-time))
                    (dolist (lane (list old peer))
                      (omnivox-preferences--reload-worker
                       lane (if (eq lane old) 'main 'notification) nil
                       (lambda (result) (push (plist-get result :outcome) reloads))))
                    (setq timer
                          (run-at-time
                           0 .015
                           (lambda ()
                             (condition-case err
                                 (dolist (lane (list old peer))
                                   (unless (gethash lane pending)
                                     (puthash lane t pending)
                                     (let ((tts-speaker-process lane)
                                           (row (list :lane (if (eq lane old) "main" "notification")
                                                      :submitted (float-time) :first nil :terminal nil)))
                                       (push row samples)
                                       (tts-speak-marked
                                        "A"
                                        (lambda (_id event)
                                          (when (equal (plist-get event :type) "utterance_started")
                                            (setf (plist-get row :first) (float-time))))
                                        (lambda (_id status)
                                          (setf (plist-get row :terminal) status)
                                          (remhash lane pending))))))
                               (error (push (error-message-string err) failures))))))
                    (setq prepared (omnivox-library--prepare-emergency (getenv "OMNIVOX_PROGRAM") "null"))
                    (setq end (float-time))
                    (cancel-timer timer)
                    (emergency-test--wait (lambda () (and (zerop (hash-table-count pending)) (= 2 (length reloads)))))
                    (unless (and (not failures) (eq tts-speaker-process old) (eq tts-notify-process peer)
                                 (cl-every (lambda (v) (member v '("applied" "unchanged"))) reloads)
                                 (cl-every (lambda (row) (eq (plist-get row :terminal) 'completed)) samples))
                      (error "Preparation disturbed old speech: %S %S %S" failures reloads samples))
                    (dolist (name '("main" "notification"))
                      (unless (cl-some (lambda (row) (and (equal name (plist-get row :lane))
                                                         (plist-get row :first) (< (plist-get row :first) end))) samples)
                        (error "No source speech observed during preparation for %s" name)))
                    (push (list :trial trial :prepare_ms (* 1000 (- end begin)) :reloads (vconcat reloads)
                                :samples (vconcat (nreverse samples))) records)
                    (princ (format "PASS preparation %d: %d completed short utterances, both lanes spoke during preparation\n" trial (length samples))))
                (when (timerp timer) (cancel-timer timer))
                (when prepared (omnivox-library--discard-emergency prepared)))))))
    (dolist (process (delete-dups (append (list tts-speaker-process tts-notify-process omnivox-library--emergency-pending)
                                         omnivox-native-guard--owners)))
      (when (processp process) (omnivox-library--retire-for-emergency process))))
  (with-temp-file (expand-file-name "availability.json" (getenv "OMNIVOX_TEST_CONFIG_DIR"))
    (insert (json-serialize (vconcat (nreverse records))))))
