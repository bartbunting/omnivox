import argparse,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('trial');a=p.parse_args();base=Path('target/guard-handoff');root=Path('/mnt/c/Users/bart/AppData/Local/Temp/omnivox-handoff-20261110')
w=lambda p:subprocess.check_output(['wslpath','-w',str(Path(p).resolve())],text=True).strip()
with (base/f'build-{a.trial}.log').open('wb') as f:r=subprocess.run(['/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',w(base/'fixtures/build.ps1'),'-Source',w(base/'fixtures/HandoffProbe.cs'),'-Output',w(root/f'HandoffProbe-{a.trial}.exe')],stdout=f,stderr=subprocess.STDOUT,timeout=60)
print('build',r.returncode,flush=True)
if r.returncode:print((base/f'build-{a.trial}.log').read_text());raise SystemExit(r.returncode)
runtime=json.loads(Path('target/guard-windows/gated-runtime.json').read_text())
with (base/f'probe-{a.trial}.log').open('wb') as f:r=subprocess.run([str(root/f'HandoffProbe-{a.trial}.exe'),w(Path(runtime['runtime'])/'flite/omnivox-flite-helper.exe'),w(root/f'result-{a.trial}.json')],stdout=f,stderr=subprocess.STDOUT,timeout=180)
print('probe',r.returncode);print((base/f'probe-{a.trial}.log').read_text()[-2000:])
