from pathlib import Path
import subprocess,json,numpy as np,wave
p=Path(Path('/tmp/omnivox-current-loopback').read_text())
def native(p):return subprocess.check_output(['wslpath','-w',str(p)],text=True).strip()
s=(p/'helper.cs').read_text().replace('{"sample_rate", 44100}, {"channels", 2}','{"sample_rate", Int32.Parse(options["--sample-rate"])}, {"channels", Int32.Parse(options["--channels"])}').replace('"frame_count", pcm.Length / 4','"frame_count", pcm.Length / (2 * Int32.Parse(options["--channels"]))')
a=s.index('                Reply(id, "audio_chunk"');b=s.index('                Reply(id, "synthesis_completed"',a)
s=s[:a]+'''                int block = Int32.Parse(options["--chunk-frames"]) * 2 * Int32.Parse(options["--channels"]);
                for (int offset=0, sequence=0;offset<pcm.Length;offset+=block,sequence++) {
                    var part=new byte[Math.Min(block,pcm.Length-offset)];
                    Array.Copy(pcm,offset,part,0,part.Length);
                    Reply(id,"audio_chunk","chunk",new Dictionary<string,object> {
                        {"sequence",sequence},{"data_base64",Convert.ToBase64String(part)}
                    });
                    Thread.Sleep(Int32.Parse(options["--chunk-delay-ms"]));
                }
'''+s[b:]
(p/'helper-v2.cs').write_text(s)
subprocess.run(['/mnt/c/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe','/nologo','/target:exe','/reference:System.Web.Extensions.dll','/out:'+native(p/'helper-v2.exe'),native(p/'helper-v2.cs')],check=True,cwd=p)
# Low-frequency nonperiodic chirp, biased above silence threshold throughout.
for rate,channels in [(44100,2),(22050,1),(48000,1),(44100,1)]:
 n=int(.12*rate);t=np.arange(n)/rate
 mono=np.round(32768*(.025+.012*np.sin(2*np.pi*(220*t+5000*t*t)+.7))).astype('<i2')
 pcm=np.repeat(mono[:,None],channels,axis=1)
 name=f'chirp-{rate}-{channels}'
 (p/(name+'.pcm')).write_bytes(pcm.tobytes())
 with wave.open(str(p/(name+'.wav')),'wb') as w:w.setparams((channels,2,rate,0,'NONE',''));w.writeframes(pcm.tobytes())
 if rate==44100 and channels==2:
  for label,lead in [('cold',0),('idle',44100),('shortidle',4410)]:
   audio=np.vstack([np.zeros((lead,2),'<i2'),pcm,np.zeros((44100,2),'<i2')])
   with wave.open(str(p/(label+'.wav')),'wb') as w:w.setparams((2,2,44100,0,'NONE',''));w.writeframes(audio.tobytes())
print('extended fixtures ready')
