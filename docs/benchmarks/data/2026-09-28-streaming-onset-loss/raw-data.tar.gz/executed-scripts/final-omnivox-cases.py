from pathlib import Path
import numpy as np,wave
p=Path(Path('/tmp/omnivox-current-loopback').read_text())
for i in range(1,6):(p/f'cold{i}.wav').write_bytes((p/'cold.wav').read_bytes())
r=np.fromfile(p/'chirp-44100-2.pcm','<i2').reshape(-1,2)
for i in range(1,4):
 audio=np.vstack([np.full((882,2),500,dtype='<i2'),r,np.zeros((44100,2),'<i2')])
 with wave.open(str(p/f'lead20-{i}.wav'),'wb') as w:w.setparams((2,2,44100,0,'NONE',''));w.writeframes(audio.tobytes())
s=Path('/tmp/run-omnivox-cases.py').read_text().replace("'2' if mode=='streaming' else '0'","'0'")
s=s.replace("rate,channels,mode=label.split('-')[1:];rate=int(rate);channels=int(channels)","rate,channels,mode=label.split('-')[1:4];rate=int(rate);channels=int(channels)")
s=s.replace("timings=[.15,.15]+[.92]*10","timings=[1.0]*10")
s=s.replace("while 'Ready to accept' not in (p/(label+'.stderr')).read_text() and timings:","while 'Ready to accept' not in read_log(p/(label+'.stderr')) and timings:")
s=s.replace('for label in sys.argv[1:]:',"def read_log(path):\n try:return path.read_text()\n except OSError:return ''\nfor label in sys.argv[1:]:")
Path('/tmp/run-omnivox-finalcases.py').write_text(s)
