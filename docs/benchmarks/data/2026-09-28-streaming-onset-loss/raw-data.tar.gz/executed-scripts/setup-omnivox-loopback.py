from pathlib import Path
import json,subprocess,wave,numpy as np
p=Path(Path('/tmp/omnivox-current-loopback').read_text())
def native(p):return subprocess.check_output(['wslpath','-w',str(p)],text=True).strip()
# Deterministic, every sample above trimming threshold, low-level diagnostic signal.
rng=np.random.default_rng(14928)
mono=(rng.choice([-1,1],4410)*rng.integers(450,1300,4410)).astype('<i2')
pcm=np.repeat(mono[:,None],2,axis=1)
(p/'reference.pcm').write_bytes(pcm.tobytes())
with wave.open(str(p/'reference.wav'),'wb') as f:f.setparams((2,2,44100,0,'NONE','not compressed'));f.writeframes(pcm.tobytes())
source=Path('test-fixtures/framework-helper.cs').read_text().replace('{"protocol_version", 1}','{"protocol_version", 5}').replace('"selected_protocol_version", 1','"selected_protocol_version", 5')
a=source.index('                var pcm = new byte[4400];');b=source.index('                Reply(id, "synthesis_started"',a)
source=source[:a]+'                var pcm = File.ReadAllBytes(options["--pcm"]);\n'+source[b:]
source=source.replace('{"sample_rate", 22050}, {"channels", 1}','{"sample_rate", 44100}, {"channels", 2}').replace('"frame_count", 2200','"frame_count", pcm.Length / 4')
(p/'helper.cs').write_text(source)
subprocess.run(['/mnt/c/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe','/nologo','/target:exe','/reference:System.Web.Extensions.dll','/out:'+native(p/'helper.exe'),native(p/'helper.cs')],check=True,cwd=p)
d=json.load(open('docs/protocol-fixtures/control-inventory-response.json'))['engines'][0]
d.update(id='org.onset',display_name='Onset test helper',default_voice_id='test')
d['voices'][0]['id']={'engine_id':'org.onset','voice_id':'test'}
d['capabilities']['audio_output']='streaming_pcm'
d['capabilities']['cancellation']='synthesis_and_playback'
d['capabilities']['markers']={k:('none' if k=='requested_anchors' else False) for k in d['capabilities']['markers']}
(p/'descriptor.json').write_text(json.dumps(d))
c=p/'config';(c/'helpers.d').mkdir(parents=True,exist_ok=True)
shipped=['espeak','winrt','macos','piper','rhvoice','flite','rutts','tgspeechbox','eloquence','dectalk']
(c/'config.json').write_text(json.dumps({'schema':2,'audio':{'backend':'device','target':'both'},'engine_overrides':{k:{'enabled':False} for k in shipped},'routing':{'preferred_engine_ids':['org.onset']}}))
(c/'helpers.d'/'onset.json').write_text(json.dumps({'schema':1,'engine_id':'org.onset','program':native(p/'helper.exe'),'arguments':['--descriptor',native(p/'descriptor.json'),'--pcm',native(p/'reference.pcm'),'--record',native(p/'helper-argv.jsonl'),'--record-synthesis',native(p/'synthesis.jsonl')]}))
print('setup complete',p)
