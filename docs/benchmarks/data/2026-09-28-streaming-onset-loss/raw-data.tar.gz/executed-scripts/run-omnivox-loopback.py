from pathlib import Path
import subprocess,os,time,json,sys
p=Path(Path('/tmp/omnivox-current-loopback').read_text())
def native(p):return subprocess.check_output(['wslpath','-w',str(p)],text=True).strip()
env={k:os.environ[k] for k in ('PATH','HOME','LANG','USER') if k in os.environ}
env.update(OMNIVOX_CONFIG_DIR=native(p/'config'),OMNIVOX_VOICE_ROOT=native(p/'voices'),RUST_LOG='info',WSLENV='OMNIVOX_CONFIG_DIR:OMNIVOX_VOICE_ROOT:RUST_LOG')
mode=sys.argv[1] if len(sys.argv)>1 else 'helper'
args=[str(p/'capture.exe'),native(p/(mode+'.f32')),'12',native(p/'release'/'omnivox.exe'),'--config-dir',native(p/'config'),'--audio-output','device']
if mode=='wav':args+=['--play-wav',native(p/'reference.wav')]
else:args+=['--engine','org.onset']
with open(p/(mode+'.stdout'),'wb') as out,open(p/(mode+'.stderr'),'wb') as err:
 q=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=out,stderr=err,env=env,cwd=p)
 time.sleep(2)
 if mode!='wav':
  for i in range(8):
   q.stdin.write(b'l {e}\n');q.stdin.flush();time.sleep(1)
 q.stdin.close()
 rc=q.wait(timeout=16)
print('exit',rc)
print((p/(mode+'.stderr')).read_text()[-6000:])
