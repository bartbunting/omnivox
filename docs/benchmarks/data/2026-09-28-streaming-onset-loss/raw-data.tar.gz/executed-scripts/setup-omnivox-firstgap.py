from pathlib import Path
import subprocess
p=Path(Path('/tmp/omnivox-current-loopback').read_text())
def native(p):return subprocess.check_output(['wslpath','-w',str(p)],text=True).strip()
s=(p/'helper-v2.cs').read_text().replace('offset+=block,sequence++','offset+=block,sequence++')
s=s.replace('                    Thread.Sleep(Int32.Parse(options["--chunk-delay-ms"]));','''                    if (sequence == 0) {
                        int delay=Int32.Parse(options["--chunk-delay-ms"]);
                        var clock=System.Diagnostics.Stopwatch.StartNew();
                        if(delay>0)Thread.Sleep(delay);
                        Console.Error.WriteLine("FIRST_GAP_US="+(clock.ElapsedTicks*1000000/System.Diagnostics.Stopwatch.Frequency));
                    }''')
(p/'helper-v3.cs').write_text(s)
subprocess.run(['/mnt/c/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe','/nologo','/target:exe','/reference:System.Web.Extensions.dll','/out:'+native(p/'helper-v3.exe'),native(p/'helper-v3.cs')],check=True,cwd=p)
s=Path('/tmp/run-omnivox-cases.py').read_text().replace("rate,channels,mode=label.split('-')[1:];rate=int(rate);channels=int(channels)","delay=int(label.split('-')[1]);rate=44100;channels=2;mode='streaming'")
s=s.replace("p/'helper-v2.exe'","p/'helper-v3.exe'").replace("'2' if mode=='streaming' else '0'","str(delay)").replace("timings=[.15,.15]+[.92]*10","timings=[1.0]*10")
s=s.replace("while 'Ready to accept' not in (p/(label+'.stderr')).read_text() and timings:","while 'Ready to accept' not in read_log(p/(label+'.stderr')) and timings:")
s=s.replace('for label in sys.argv[1:]:',"def read_log(path):\n try:return path.read_text()\n except OSError:return ''\nfor label in sys.argv[1:]:")
Path('/tmp/run-omnivox-firstgap.py').write_text(s)
