from pathlib import Path
import os,subprocess,time,json,sys
p=Path(Path('/tmp/omnivox-current-loopback').read_text())
def native(p):return subprocess.check_output(['wslpath','-w',str(p)],text=True).strip()
env={k:os.environ[k] for k in ('PATH','HOME','LANG','USER') if k in os.environ}
env.update(OMNIVOX_VOICE_ROOT=native(p/'voices'),RUST_LOG='info',WSLENV='OMNIVOX_VOICE_ROOT:RUST_LOG')
for label in sys.argv[1:]:
 if (p/(label+'.f32')).exists():raise RuntimeError('Refuse overwrite '+label)
 if label.startswith('wav-'):
  config=p/'config';args=['--play-wav',native(p/(label[4:]+'.wav'))];seconds=4;timings=[]
 else:
  rate,channels,mode=label.split('-')[1:];rate=int(rate);channels=int(channels)
  config=p/label;(config/'helpers.d').mkdir(parents=True)
  (config/'config.json').write_bytes((p/'config'/'config.json').read_bytes())
  descriptor=json.loads((p/'descriptor.json').read_text());descriptor['capabilities']['audio_output']=mode+'_pcm'
  (config/'descriptor.json').write_text(json.dumps(descriptor))
  manifest={'schema':1,'engine_id':'org.onset','program':native(p/'helper-v2.exe'),'arguments':['--descriptor',native(config/'descriptor.json'),'--pcm',native(p/f'chirp-{rate}-{channels}.pcm'),'--record',native(config/'argv.jsonl'),'--record-synthesis',native(config/'synthesis.jsonl'),'--sample-rate',str(rate),'--channels',str(channels),'--chunk-frames','256','--chunk-delay-ms','2' if mode=='streaming' else '0']}
  (config/'helpers.d'/'onset.json').write_text(json.dumps(manifest))
  args=['--engine','org.onset'];seconds=14
  # First two utterances have only 30ms idle; subsequent ten have 800ms idle.
  timings=[.15,.15]+[.92]*10
  dump=subprocess.run([str(p/'release'/'omnivox.exe'),'--config-dir',native(config),'--engine','org.onset','--audio-output','null','--dump-wav','test',native(p/(label+'.reference.wav')),'e'],env=env,cwd=p,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
  (p/(label+'.dump.log')).write_bytes(dump.stdout+dump.stderr)
  if dump.returncode:raise RuntimeError(dump.stderr.decode())
 command=[str(p/'capture.exe'),native(p/(label+'.f32')),str(seconds),native(p/'release'/'omnivox.exe'),'--config-dir',native(config),'--audio-output','device',*args]
 with open(p/(label+'.stdout'),'wb') as out,open(p/(label+'.stderr'),'wb') as err:
  child=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=out,stderr=err,env=env,cwd=p)
  deadline=time.monotonic()+10
  while 'Ready to accept' not in (p/(label+'.stderr')).read_text() and timings:
   if child.poll() is not None or time.monotonic()>deadline:raise RuntimeError((p/(label+'.stderr')).read_text())
   time.sleep(.02)
  if timings:time.sleep(1.1)
  sent=[]
  for delay in timings:
   sent.append(time.time());child.stdin.write(b'l {e}\n');child.stdin.flush();time.sleep(delay)
  child.stdin.close();result=child.wait(timeout=seconds+5)
 (p/(label+'.run.json')).write_text(json.dumps({'command':command,'returncode':result,'sent_unix':sent},indent=2))
 print(label,'exit',result,flush=True)
