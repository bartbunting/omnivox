#define _WIN32_WINNT 0x0A00
#include <windows.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <cstdio>
int main(){CoInitializeEx(nullptr,COINIT_MULTITHREADED);IMMDeviceEnumerator* en=nullptr;IMMDevice* d=nullptr;IAudioClient* a=nullptr;WAVEFORMATEX* f=nullptr;LPWSTR id=nullptr;
HRESULT hr=CoCreateInstance(__uuidof(MMDeviceEnumerator),nullptr,CLSCTX_ALL,__uuidof(IMMDeviceEnumerator),(void**)&en);if(FAILED(hr))return 1;
if(FAILED(en->GetDefaultAudioEndpoint(eRender,eConsole,&d)))return 2;
d->GetId(&id);wprintf(L"default_eConsole=%ls\n",id);CoTaskMemFree(id);
if(FAILED(d->Activate(__uuidof(IAudioClient),CLSCTX_ALL,nullptr,(void**)&a)))return 3;
if(FAILED(a->GetMixFormat(&f)))return 4;
printf("format_tag=%u channels=%u sample_rate=%lu bits=%u block_align=%u extra_bytes=%u\n",f->wFormatTag,f->nChannels,f->nSamplesPerSec,f->wBitsPerSample,f->nBlockAlign,f->cbSize);
CoTaskMemFree(f);a->Release();d->Release();en->Release();CoUninitialize();return 0;}
