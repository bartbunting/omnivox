;;; -*- lexical-binding: t -*-
(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(omnivox-audio-device-preferences
   '(("windows:wasapi:ursys-8m3wmb4" speaker
      "wasapi:{0.0.0.00000000}.{ca90b428-a461-4916-bb51-7e74cc571cef}"
      "Current native endpoint")
     ("windows:wasapi:ursys-8m3wmb4" notification "default" "Default"))))
(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 )
