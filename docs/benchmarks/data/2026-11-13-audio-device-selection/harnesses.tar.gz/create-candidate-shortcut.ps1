$ErrorActionPreference='Stop'
$root=Join-Path $env:LOCALAPPDATA 'Emacsvox\AudioDeviceTests\client-20261113'
$desktop=[Environment]::GetFolderPath('Desktop')
$path=Join-Path $desktop 'Emacsvox Audio Devices.lnk'
if (Test-Path -LiteralPath $path) { throw 'Candidate shortcut already exists; refusing to overwrite it.' }
$normal=Join-Path $desktop 'Emacsvox Windows.lnk'
$before=(Get-FileHash -LiteralPath $normal).Hash
foreach ($engine in @('eloquence','dectalk')) {
 $reportFile=Get-ChildItem -LiteralPath (Join-Path $root 'logs') -Filter ("personal-$engine-*.json") | Sort-Object Name | Select-Object -Last 1
 $report=[IO.File]::ReadAllText($reportFile.FullName) | ConvertFrom-Json
 if ($report.result -ne 'passed' -or $report.client_process_cleanup -ne 'retired' -or
     $report.engines.Count -ne 2 -or @($report.engines | Where-Object { $_ -ne $engine }).Count) { throw "Unqualified personal profile: $engine" }
}
$runtime=Join-Path $env:LOCALAPPDATA 'Emacsvox\Omnivox\runtime\9481974fc10b5ace\omnivox.exe'
$remaining=@(Get-CimInstance Win32_Process -Filter "Name='omnivox.exe'" | Where-Object { $_.ExecutablePath -eq $runtime })
if ($remaining.Count) { throw 'Candidate test workers still exist; inspect cleanup.' }
$shell=New-Object -ComObject WScript.Shell
$original=$shell.CreateShortcut($normal)
$shortcut=$shell.CreateShortcut($path)
$shortcut.TargetPath=Join-Path $root 'evox-windows-launcher.exe'
$shortcut.WorkingDirectory=$root
$shortcut.IconLocation=$original.IconLocation
$shortcut.Description='Emacsvox audio device selection candidate: main and notifications, separate Apply and Save'
$shortcut.Save()
$readback=$shell.CreateShortcut($path)
if ($readback.TargetPath -ne $shortcut.TargetPath -or (Get-FileHash -LiteralPath $normal).Hash -ne $before) { throw 'Shortcut verification failed.' }
$report=[ordered]@{created_utc=[DateTime]::UtcNow.ToString('o'); shortcut=$path; target=$readback.TargetPath;
 runtime=$runtime; normal_shortcut_sha256=$before.ToLower(); normal_shortcut_unchanged=$true;
 candidate_test_processes=$remaining.Count; default_engine='eloquence'; early_speech=$true;
 personal_configuration='Existing shared personal configuration; no saved output choices changed by handoff';
 launcher_sha256=(Get-FileHash -LiteralPath $shortcut.TargetPath).Hash.ToLower();
 script_sha256=(Get-FileHash -LiteralPath (Join-Path $root 'evox-windows.ps1')).Hash.ToLower()}
$json=$report | ConvertTo-Json -Depth 5
[IO.File]::WriteAllText((Join-Path $root 'handoff.json'),$json,(New-Object Text.UTF8Encoding($false)))
Write-Output $json
