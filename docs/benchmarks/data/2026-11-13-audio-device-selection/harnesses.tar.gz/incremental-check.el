(let* ((root (getenv "EMACSVOX_DIR")) (lisp (expand-file-name "lisp/" root)))
  (load (expand-file-name "emacsvox-preamble.el" lisp) nil t)
  (require 'bytecomp)
  (unless (byte-compile-file (expand-file-name "ui/omnivox-output-devices.el" lisp)) (error "Compilation failed")))
