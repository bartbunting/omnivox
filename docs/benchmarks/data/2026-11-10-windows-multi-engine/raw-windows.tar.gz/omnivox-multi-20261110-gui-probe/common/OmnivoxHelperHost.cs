// Copyright (C) 2026 Bart Bunting
// SPDX-License-Identifier: GPL-2.0-or-later
//
// This file is not part of GNU Emacs, but the same permissions apply.
// See the file COPYING in this distribution.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

internal static class OmnivoxHelperLog
{
    private static readonly object OutputLock = new object();

    internal static void Event(string name, string details)
    {
        lock (OutputLock)
        {
            Console.Error.WriteLine(
                "{0:O} helper_event={1} pid={2} thread={3}{4}",
                DateTime.UtcNow, name, Process.GetCurrentProcess().Id,
                Thread.CurrentThread.ManagedThreadId,
                String.IsNullOrEmpty(details) ? "" : " " + details);
            Console.Error.Flush();
        }
    }

    internal static string ExceptionDetails(Exception error)
    {
        return error.ToString().Replace('\r', ' ').Replace('\n', ' ');
    }
}

internal sealed class OmnivoxHelperVoice
{
    internal string Id;
    internal string Name;
    internal string Language;
    internal string Gender;

    internal OmnivoxHelperVoice(string id, string name, string language,
        string gender)
    {
        Id = id;
        Name = name;
        Language = language;
        Gender = gender;
    }
}

internal sealed class OmnivoxHelperCapabilities
{
    internal bool Rate { get; set; }
    internal bool AveragePitch { get; set; }
    internal bool PitchRange { get; set; }
    internal bool Stress { get; set; }
    internal bool Richness { get; set; }
    internal bool Volume { get; set; }
    internal bool WordMarkers { get; set; }
    internal bool SentenceMarkers { get; set; }
    internal bool PhonemeMarkers { get; set; }
    internal bool NativeIndexMarkers { get; set; }
    internal string RequestedAnchors { get; set; }
    internal bool LanguageSwitching { get; set; }
    internal string TextRepertoire { get; set; }
}

internal sealed class OmnivoxHelperAnchor
{
    internal string Id;
    internal uint TextOffset;
    internal string Affinity;

    internal OmnivoxHelperAnchor(string id, uint textOffset, string affinity)
    {
        Id = id;
        TextOffset = textOffset;
        Affinity = affinity;
    }
}

internal sealed class OmnivoxHelperMarker
{
    internal string Kind;
    internal ulong FrameOffset;
    internal uint? TextStart;
    internal uint? TextLength;
    internal string Value;
    internal string Resolution;

    internal OmnivoxHelperMarker(string kind, ulong frameOffset,
        uint? textStart, uint? textLength, string value)
        : this(kind, frameOffset, textStart, textLength, value, null)
    {
    }

    internal OmnivoxHelperMarker(string kind, ulong frameOffset,
        uint? textStart, uint? textLength, string value,
        string resolution)
    {
        Kind = kind;
        FrameOffset = frameOffset;
        TextStart = textStart;
        TextLength = textLength;
        Value = value;
        Resolution = resolution;
    }
}

internal sealed class OmnivoxTextSpan
{
    internal int Start;
    internal int Length;

    internal OmnivoxTextSpan(int start, int length)
    {
        Start = start;
        Length = length;
    }
}

/// <summary>
/// Conservative source-text boundaries shared by capture adapters whose
/// native APIs can time inserted indexes but do not report sentence ranges.
/// </summary>
internal static class OmnivoxTextBoundaries
{
    internal static OmnivoxTextSpan[] Sentences(string text)
    {
        List<OmnivoxTextSpan> spans = new List<OmnivoxTextSpan>();
        int position = 0;
        while (position < text.Length)
        {
            while (position < text.Length && Char.IsWhiteSpace(text, position))
            {
                ++position;
            }
            if (position >= text.Length)
            {
                break;
            }

            int start = position;
            bool completed = false;
            while (position < text.Length)
            {
                char value = text[position];
                if (value == '\r' || value == '\n')
                {
                    AddNonempty(spans, start, position);
                    completed = true;
                    break;
                }
                ++position;
                if (!IsSentenceTerminator(value))
                {
                    continue;
                }
                while (position < text.Length &&
                    IsSentenceCloser(text[position]))
                {
                    ++position;
                }
                if (position == text.Length ||
                    Char.IsWhiteSpace(text, position))
                {
                    AddNonempty(spans, start, position);
                    completed = true;
                    break;
                }
            }
            if (!completed)
            {
                AddNonempty(spans, start, text.Length);
                position = text.Length;
            }
        }
        return spans.ToArray();
    }

    private static void AddNonempty(List<OmnivoxTextSpan> spans,
        int start, int end)
    {
        if (end > start)
        {
            spans.Add(new OmnivoxTextSpan(start, end - start));
        }
    }

    private static bool IsSentenceTerminator(char value)
    {
        return value == '.' || value == '!' || value == '?' ||
            value == '\u2026' || value == '\u3002' ||
            value == '\uff01' || value == '\uff1f';
    }

    private static bool IsSentenceCloser(char value)
    {
        return value == '\'' || value == '"' || value == '\u2019' ||
            value == '\u201d' || value == ')' || value == ']' ||
            value == '}';
    }
}

internal sealed class OmnivoxCaptureResult
{
    internal byte[] Audio;
    internal OmnivoxHelperMarker[] Markers;

    internal OmnivoxCaptureResult(byte[] audio,
        OmnivoxHelperMarker[] markers)
    {
        Audio = audio;
        Markers = markers;
    }
}

internal interface IOmnivoxCaptureSink
{
    void Audio(byte[] audio, int offset, int count);
    void Markers(OmnivoxHelperMarker[] markers);
}

internal interface IOmnivoxCaptureEngine : IDisposable
{
    string EngineId { get; }
    string DisplayName { get; }
    string Version { get; }
    string HelperName { get; }
    string DefaultVoiceId { get; }
    int SampleRate { get; }
    int Channels { get; }
    bool SupportsProgressiveSynthesis { get; }
    OmnivoxHelperVoice[] Voices { get; }
    OmnivoxHelperCapabilities Capabilities { get; }
    OmnivoxCaptureResult Synthesize(string text, string voiceId, double rate,
        double pitch, double? pitchRange, double? stress, double? richness,
        double volume, OmnivoxHelperAnchor[] anchors,
        Func<bool> cancellationRequested, IOmnivoxCaptureSink sink);
    void Stop();
}

internal static class OmnivoxHelperRuntime
{
    private const int MaximumDiagnosticLength = 16 * 1024;

    internal static int Run(string engineId, string displayName,
        string helperName, Func<IOmnivoxCaptureEngine> createEngine)
    {
        IOmnivoxCaptureEngine engine;
        try
        {
            engine = createEngine();
        }
        catch (Exception error)
        {
            OmnivoxHelperLog.Event("runtime_unavailable",
                "engine=" + engineId + " error=\"" +
                OmnivoxHelperLog.ExceptionDetails(error) + "\"");
            return new OmnivoxHelperHost(engineId, displayName, helperName,
                RuntimeDiagnostic(error)).Run();
        }

        using (engine)
        {
            return new OmnivoxHelperHost(engine).Run();
        }
    }

    private static string RuntimeDiagnostic(Exception error)
    {
        Exception current = error;
        while (current != null)
        {
            OmnivoxRuntimeUnavailableException unavailable = current as
                OmnivoxRuntimeUnavailableException;
            if (unavailable != null)
            {
                return Bound(unavailable.Message);
            }
            current = current.InnerException;
        }

        string diagnostic = "The " + error.GetType().Name +
            " prevented native runtime initialization";
        current = error;
        while (current != null)
        {
            if (!String.IsNullOrEmpty(current.Message))
            {
                diagnostic += ": " + current.Message;
            }
            current = current.InnerException;
        }
        return Bound(diagnostic);
    }

    private static string Bound(string value)
    {
        if (String.IsNullOrEmpty(value))
        {
            return "The native speech runtime is unavailable";
        }
        return value.Length <= MaximumDiagnosticLength ? value :
            value.Substring(0, MaximumDiagnosticLength);
    }
}

/// <summary>
/// Engine-neutral implementation of Omnivox helper protocol versions 1-5.
/// Native adapters provide inventory, captured or progressive PCM, and
/// interruption only.
/// </summary>
internal sealed class OmnivoxHelperHost
{
    private int SupportedProtocolVersion
    {
        get { return engine is IOmnivoxParameterEngine ? 6 : 5; }
    }
    private const int ProgressiveProtocolVersion = 5;
    private const int ExtendedRateProtocolVersion = 4;
    private const int ExtendedAcssProtocolVersion = 3;
    private const int AnchorProtocolVersion = 2;
    private const int LegacyProtocolVersion = 1;
    private const int MaximumFrameBytes = 1024 * 1024;
    private const int MaximumTextBytes = 256 * 1024;
    private const int MaximumAudioChunkBytes = 256 * 1024;
    private const int MaximumAudioBytes = 128 * 1024 * 1024;
    private const int MaximumMarkers = 4096;
    private const int MaximumStringLength = 16 * 1024;
    private const int MaximumAnchorIdBytes = 128;

    private sealed class ProtocolException : Exception
    {
        internal readonly string Code;
        internal readonly bool Retryable;

        internal ProtocolException(string code, string message,
            bool retryable)
            : base(message)
        {
            Code = code;
            Retryable = retryable;
        }
    }

    private sealed class ActiveSynthesis
    {
        internal ulong RequestId;
        internal string Text;
        internal string VoiceId;
        internal double Rate;
        internal double Pitch;
        internal double? PitchRange;
        internal double? Stress;
        internal double? Richness;
        internal double Volume;
        internal OmnivoxHelperAnchor[] Anchors;
        internal bool Progressive;
        internal bool Started;
        internal IOmnivoxParameterSynthesis NativePlan;
        internal volatile bool Cancelled;
        internal Thread Worker;
    }

    private sealed class ProgressiveWireSink : IOmnivoxCaptureSink
    {
        private readonly OmnivoxHelperHost host;
        private readonly ActiveSynthesis synthesis;
        private readonly int sourceChannels;
        private readonly ulong textBytes;
        private readonly HashSet<string> requestedAnchors;
        private readonly HashSet<string> resolvedAnchors =
            new HashSet<string>(StringComparer.Ordinal);
        private uint sequence;
        private ulong frameCount;
        private int markerCount;
        private ulong? lastMarkerOffset;
        private bool completed;

        internal ProgressiveWireSink(OmnivoxHelperHost host,
            ActiveSynthesis synthesis)
        {
            this.host = host;
            this.synthesis = synthesis;
            sourceChannels = host.engine.Channels;
            if ((sourceChannels != 1 && sourceChannels != 2) ||
                host.engine.SampleRate <= 0)
            {
                throw new InvalidOperationException(
                    "progressive Windows helper PCM has an invalid native format");
            }
            textBytes = (ulong)Encoding.UTF8.GetByteCount(synthesis.Text);
            requestedAnchors = new HashSet<string>(StringComparer.Ordinal);
            foreach (OmnivoxHelperAnchor anchor in synthesis.Anchors)
            {
                requestedAnchors.Add(anchor.Id);
            }
        }

        internal ulong FrameCount { get { return frameCount; } }
        internal int MarkerCount { get { return markerCount; } }

        public void Audio(byte[] audio, int offset, int count)
        {
            EnsureActive();
            int sourceFrameBytes = checked(sourceChannels * 2);
            if (audio == null || offset < 0 || count <= 0 ||
                offset > audio.Length - count || count % sourceFrameBytes != 0)
            {
                throw new InvalidOperationException(
                    "native engine emitted an invalid progressive PCM window");
            }

            WriteAudio(audio, offset, count);
        }

        public void Markers(OmnivoxHelperMarker[] markers)
        {
            EnsureActive();
            if (markers == null || markers.Length == 0 ||
                markerCount > MaximumMarkers - markers.Length)
            {
                throw new InvalidOperationException(
                    "native engine emitted an invalid progressive marker batch");
            }

            OmnivoxHelperMarker[] converted =
                new OmnivoxHelperMarker[markers.Length];
            for (int index = 0; index < markers.Length; ++index)
            {
                OmnivoxHelperMarker marker = markers[index];
                ValidateMarker(marker);
                if (marker.FrameOffset < frameCount)
                {
                    throw new InvalidOperationException(
                        "progressive native marker at frame " +
                        marker.FrameOffset.ToString(CultureInfo.InvariantCulture) +
                        " arrived after " + frameCount.ToString(
                            CultureInfo.InvariantCulture) + " PCM frames");
                }
                if (lastMarkerOffset.HasValue &&
                    marker.FrameOffset < lastMarkerOffset.Value)
                {
                    throw new InvalidOperationException(
                        "progressive native markers are not monotonic");
                }
                lastMarkerOffset = marker.FrameOffset;
                converted[index] = new OmnivoxHelperMarker(marker.Kind,
                    marker.FrameOffset, marker.TextStart, marker.TextLength,
                    marker.Value, marker.Resolution);
            }
            markerCount += markers.Length;
            host.WriteMarkers(synthesis, converted);
        }

        internal ulong Complete()
        {
            EnsureActive();
            if (lastMarkerOffset.HasValue &&
                lastMarkerOffset.Value > frameCount)
            {
                throw new InvalidOperationException(
                    "progressive native marker exceeds the completed PCM");
            }
            completed = true;
            return frameCount;
        }

        private void WriteAudio(byte[] audio, int audioOffset, int audioCount)
        {
            int sourceFrameBytes = checked(sourceChannels * 2);
            int maximumChunk = MaximumAudioChunkBytes -
                MaximumAudioChunkBytes % sourceFrameBytes;
            int end = checked(audioOffset + audioCount);
            for (int offset = audioOffset; offset < end;
                offset += maximumChunk)
            {
                EnsureActive();
                int count = Math.Min(maximumChunk, end - offset);
                ulong frames = (ulong)(count / sourceFrameBytes);
                if (frameCount >
                    (ulong)(MaximumAudioBytes / sourceFrameBytes) - frames)
                {
                    throw new InvalidOperationException(
                        "progressive synthesis exceeded the 128 MiB audio limit");
                }
                Dictionary<string, object> response = host.Response(
                    synthesis.RequestId, "audio_chunk");
                Dictionary<string, object> chunk =
                    new Dictionary<string, object>();
                chunk["sequence"] = sequence++;
                chunk["data_base64"] = Convert.ToBase64String(audio,
                    offset, count);
                response["chunk"] = chunk;
                host.WriteSynthesisFrame(synthesis, response, false);
                frameCount += frames;
            }
        }

        private void ValidateMarker(OmnivoxHelperMarker marker)
        {
            if (marker == null ||
                (marker.Kind != "word" && marker.Kind != "sentence" &&
                 marker.Kind != "phoneme" &&
                 marker.Kind != "native_index" &&
                 marker.Kind != "requested_anchor") ||
                marker.TextStart.HasValue != marker.TextLength.HasValue ||
                (marker.Value != null &&
                 Encoding.UTF8.GetByteCount(marker.Value) >
                    MaximumStringLength) ||
                (marker.Resolution != null &&
                 (marker.Kind != "requested_anchor" ||
                  (marker.Resolution != "exact" &&
                   marker.Resolution != "word_boundary" &&
                   marker.Resolution != "span_boundary" &&
                   marker.Resolution != "omitted"))) ||
                (marker.TextStart.HasValue &&
                 (ulong)marker.TextStart.Value + marker.TextLength.Value >
                    textBytes))
            {
                throw new InvalidOperationException(
                    "native engine emitted an invalid progressive marker");
            }
            if (marker.Kind == "requested_anchor" &&
                (marker.Value == null ||
                 !requestedAnchors.Contains(marker.Value) ||
                 !resolvedAnchors.Add(marker.Value)))
            {
                throw new InvalidOperationException(
                    "native engine emitted an unknown or duplicate anchor");
            }
        }

        private void EnsureActive()
        {
            if (!synthesis.Started)
                throw new InvalidOperationException("native output preceded application receipt");
            if (completed)
            {
                throw new InvalidOperationException(
                    "progressive synthesis is already complete");
            }
            if (synthesis.Cancelled)
            {
                throw new OperationCanceledException(
                    "progressive synthesis was cancelled");
            }
        }
    }

    private readonly IOmnivoxCaptureEngine engine;
    private readonly string engineId;
    private readonly string displayName;
    private readonly string helperName;
    private readonly string runtimeUnavailableReason;
    private readonly TextReader input;
    private readonly TextWriter output;
    private readonly JavaScriptSerializer json;
    private readonly object outputLock = new object();
    // Lock order is stateLock, then outputLock. Publish cancellation, speech
    // frames and terminal retirement under this same guard. Native Stop must
    // run outside it: native callbacks may be waiting to publish speech.
    private readonly object stateLock = new object();
    private ActiveSynthesis active;
    private bool negotiated;
    private int selectedProtocolVersion;
    private bool shuttingDown;

    internal OmnivoxHelperHost(IOmnivoxCaptureEngine engine)
        : this(engine, null, null, null, null, null, null)
    {
    }

    internal OmnivoxHelperHost(string engineId, string displayName,
        string helperName, string runtimeUnavailableReason)
        : this(null, engineId, displayName, helperName,
            runtimeUnavailableReason, null, null)
    {
    }

    internal OmnivoxHelperHost(IOmnivoxCaptureEngine engine,
        TextReader input, TextWriter output)
        : this(engine, null, null, null, null, input, output)
    {
    }

    private OmnivoxHelperHost(IOmnivoxCaptureEngine engine, string engineId,
        string displayName, string helperName,
        string runtimeUnavailableReason, TextReader input, TextWriter output)
    {
        if (engine != null)
        {
            engineId = engine.EngineId;
            displayName = engine.DisplayName;
            helperName = engine.HelperName;
        }
        this.engine = engine;
        this.engineId = engineId;
        this.displayName = displayName;
        this.helperName = helperName;
        this.runtimeUnavailableReason = runtimeUnavailableReason;

        if (String.IsNullOrEmpty(engineId) ||
            String.IsNullOrEmpty(displayName) ||
            String.IsNullOrEmpty(helperName))
        {
            throw new ArgumentException("helper identity is incomplete");
        }
        if (engine != null &&
            (String.IsNullOrEmpty(engine.Version) ||
             String.IsNullOrEmpty(engine.DefaultVoiceId) ||
             engine.SampleRate <= 0 || engine.Channels <= 0 ||
             engine.Voices == null || engine.Voices.Length == 0 ||
             engine.Capabilities == null))
        {
            throw new ArgumentException("capture engine metadata is incomplete",
                "engine");
        }
        if (engine != null && !HasVoice(engine.DefaultVoiceId))
        {
            throw new ArgumentException(
                "capture engine default voice is not in inventory", "engine");
        }
        if (engine == null && String.IsNullOrEmpty(runtimeUnavailableReason))
        {
            throw new ArgumentException(
                "an unavailable helper requires a diagnostic",
                "runtimeUnavailableReason");
        }
        if (this.runtimeUnavailableReason != null &&
            this.runtimeUnavailableReason.Length > MaximumStringLength)
        {
            this.runtimeUnavailableReason = this.runtimeUnavailableReason
                .Substring(0, MaximumStringLength);
        }

        this.input = input ?? new StreamReader(Console.OpenStandardInput(),
            new UTF8Encoding(false, true), false, 4096);
        if (output == null)
        {
            StreamWriter standardOutput = new StreamWriter(
                Console.OpenStandardOutput(), new UTF8Encoding(false), 4096);
            standardOutput.AutoFlush = true;
            output = standardOutput;
        }
        this.output = output;
        json = new JavaScriptSerializer();
        json.MaxJsonLength = MaximumFrameBytes;
        json.RecursionLimit = 32;
        OmnivoxHelperLog.Event("process_started",
            "engine=" + engineId + " engine_version=" +
            (engine == null ? "unavailable" : engine.Version) +
            " helper=\"" + helperName + "\" runtime=" +
            (engine == null ? "unavailable" : "available"));
    }

    internal int Run()
    {
        OmnivoxHelperLog.Event("protocol_loop_started", "");
        while (!shuttingDown)
        {
            string line;
            try
            {
                line = ReadBoundedLine();
            }
            catch (ProtocolException error)
            {
                WriteError(null, error.Code, error.Message, error.Retryable);
                continue;
            }
            if (line == null)
            {
                break;
            }
            Dispatch(line);
        }

        StopAndJoinActive();
        OmnivoxHelperLog.Event("protocol_loop_stopped", "");
        return 0;
    }

    private string ReadBoundedLine()
    {
        StringBuilder line = new StringBuilder();
        int encodedBytes = 0;
        bool oversized = false;
        while (true)
        {
            int value = input.Read();
            if (value < 0)
            {
                if (line.Length == 0 && !oversized)
                {
                    return null;
                }
                throw Fault("invalid_request",
                    "helper frame ended before its newline terminator", false);
            }
            char character = (char)value;
            if (character == '\n')
            {
                break;
            }
            encodedBytes += character <= 0x7f ? 1 :
                (character <= 0x7ff ? 2 : 3);
            if (encodedBytes > MaximumFrameBytes)
            {
                oversized = true;
            }
            if (!oversized)
            {
                line.Append(character);
            }
        }

        if (oversized)
        {
            throw Fault("payload_too_large",
                "helper frame exceeds the 1 MiB limit", false);
        }
        if (line.Length > 0 && line[line.Length - 1] == '\r')
        {
            line.Length -= 1;
        }
        return line.ToString();
    }

    private void Dispatch(string line)
    {
        ulong? requestId = null;
        try
        {
            new JsonKeyCheck(line, json).Validate();
            IDictionary<string, object> request = json.DeserializeObject(line)
                as IDictionary<string, object>;
            if (request == null)
            {
                throw Fault("invalid_request",
                    "helper request must be a JSON object", false);
            }

            requestId = ReadUnsigned(request, "request_id");
            int version = ReadInteger(request, "protocol_version");
            if (version < LegacyProtocolVersion ||
                version > SupportedProtocolVersion)
            {
                throw Fault("unsupported_version",
                    "unsupported helper protocol version " + version, false);
            }
            if (version == 6)
            {
                new JsonKeyCheck(line, json, true).Validate();
                if (requestId == 0) throw Fault("invalid_request", "request_id must be positive", false);
            }
            string type = ReadString(request, "type", false);
            if (!negotiated && type != "hello")
            {
                throw Fault("invalid_request",
                    "hello must be the first helper request", false);
            }
            if (negotiated && version != selectedProtocolVersion)
            {
                throw Fault("unsupported_version",
                    "request does not use the negotiated helper protocol", false);
            }

            switch (type)
            {
                case "hello":
                    HandleHello(requestId.Value, version, request);
                    break;
                case "describe":
                    RequireFields(request, "protocol_version", "request_id",
                        "type");
                    WriteDescriptor(requestId.Value);
                    break;
                case "ping":
                    RequireFields(request, "protocol_version", "request_id",
                        "type");
                    WriteSimple(requestId.Value, "pong");
                    break;
                case "synthesize":
                    HandleSynthesize(requestId.Value, request);
                    break;
                case "get_engine_parameters_v1":
                case "explain_voice_parameters_v1":
                    if (selectedProtocolVersion != 6)
                        throw Fault("invalid_request", "parameter requests require helper 6", false);
                    OmnivoxParameterWire.Bounded(request);
                    IOmnivoxParameterEngine parameterEngine = (IOmnivoxParameterEngine)engine;
                    Dictionary<string, object> parameterResponse;
                    if (type == "get_engine_parameters_v1")
                    {
                        RequireFields(request, "protocol_version", "request_id", "type",
                            "engine_id", "voice_id", "cursor", "expected_catalogue_revision");
                        parameterResponse = Response(requestId.Value, "engine_parameters_v1");
                        parameterResponse["engine_id"] = request["engine_id"];
                        parameterResponse["result"] = parameterEngine.GetParameters(request);
                    }
                    else
                    {
                        RequireFields(request, "protocol_version", "request_id", "type", "source");
                        parameterResponse = Response(requestId.Value, "voice_parameters_explained_v1");
                        parameterResponse["result"] = parameterEngine.ExplainParameters(request["source"]);
                    }
                    OmnivoxParameterWire.Bounded(parameterResponse);
                    WriteFrame(parameterResponse);
                    break;
                case "cancel":
                    HandleCancel(requestId.Value, request);
                    break;
                case "shutdown":
                    RequireFields(request, "protocol_version", "request_id",
                        "type");
                    WriteSimple(requestId.Value, "shutting_down");
                    shuttingDown = true;
                    break;
                default:
                    throw Fault("invalid_request",
                        "unknown helper request type: " + type, false);
            }
        }
        catch (OmnivoxParameterException error)
        {
            WriteError(requestId, error.Code, error.Message, error.Retryable);
        }
        catch (ProtocolException error)
        {
            WriteError(requestId, error.Code, error.Message, error.Retryable);
        }
        catch (Exception error)
        {
            WriteError(requestId, "invalid_request",
                "invalid helper request: " + error.Message, false);
        }
    }

    private void HandleHello(ulong requestId, int requestVersion,
        IDictionary<string, object> request)
    {
        RequireFields(request, "protocol_version", "request_id", "type",
            "supported_protocol_versions");
        if (negotiated)
        {
            throw Fault("invalid_request",
                "helper protocol is already negotiated", false);
        }
        object value = Required(request, "supported_protocol_versions");
        IEnumerable versions = value as IEnumerable;
        if (versions == null || value is string)
        {
            throw Fault("invalid_request",
                "supported_protocol_versions must be an array", false);
        }
        int count = 0;
        int highestSupported = 0;
        HashSet<int> seen = new HashSet<int>();
        foreach (object item in versions)
        {
            int version = ConvertInteger(item,
                "supported_protocol_versions");
            ++count;
            if (count > 16 || version <= 0 || !seen.Add(version))
            {
                throw Fault("invalid_request",
                    "supported_protocol_versions is invalid", false);
            }
            if (version >= LegacyProtocolVersion &&
                version <= SupportedProtocolVersion)
            {
                highestSupported = Math.Max(highestSupported, version);
            }
        }
        if (count == 0 ||
            highestSupported == 0 ||
            !seen.Contains(requestVersion))
        {
            throw Fault("unsupported_version",
                "no supported helper protocol version was offered", false);
        }

        selectedProtocolVersion = highestSupported;
        negotiated = true;
        Dictionary<string, object> response = Response(requestId, "hello");
        response["selected_protocol_version"] = selectedProtocolVersion;
        response["helper_name"] = helperName;
        response["helper_version"] = "0.1.0";
        WriteFrame(response);
    }

    private void HandleSynthesize(ulong requestId,
        IDictionary<string, object> request)
    {
        if (selectedProtocolVersion == 6)
        {
            RequireFields(request, "protocol_version", "request_id", "type",
                "text", "settings", "anchors", "voice_parameters");
        }
        else if (selectedProtocolVersion >= AnchorProtocolVersion)
        {
            RequireFields(request, "protocol_version", "request_id", "type",
                "text", "settings", "anchors");
        }
        else
        {
            RequireFields(request, "protocol_version", "request_id", "type",
                "text", "settings");
        }
        if (engine == null)
        {
            throw Fault("not_available", runtimeUnavailableReason, false);
        }
        string text = ReadText(request);
        if (Encoding.UTF8.GetByteCount(text) > MaximumTextBytes)
        {
            throw Fault("payload_too_large",
                "synthesis text exceeds the 256 KiB limit", false);
        }
        if (text.IndexOf('\0') >= 0)
        {
            throw Fault("invalid_parameter",
                "native speech text cannot contain a NUL character", false);
        }

        IDictionary<string, object> settings = Required(request, "settings")
            as IDictionary<string, object>;
        if (settings == null)
        {
            throw Fault("invalid_parameter",
                "settings must be a JSON object", false);
        }
        if (selectedProtocolVersion >= ExtendedAcssProtocolVersion)
        {
            RequireFields(settings, "voice_id", "rate", "pitch", "volume",
                "pitch_range", "stress", "richness");
        }
        else
        {
            RequireFields(settings, "voice_id", "rate", "pitch", "volume");
        }
        if (selectedProtocolVersion == 6) settings = OmnivoxParameterSettings.Normalize(settings);
        string voiceId = settings["voice_id"] == null ?
            engine.DefaultVoiceId : ReadString(settings, "voice_id", false);
        if (!HasVoice(voiceId))
        {
            throw Fault("voice_not_found",
                    displayName + " voice was not found: " + voiceId,
                false);
        }

        ActiveSynthesis synthesis = new ActiveSynthesis();
        synthesis.RequestId = requestId;
        synthesis.Text = text;
        synthesis.VoiceId = voiceId;
        double maximumRate = selectedProtocolVersion >=
            ExtendedRateProtocolVersion ? 2.0 : 1.0;
        synthesis.Rate = ReadNumber(settings, "rate", 0.0, maximumRate);
        synthesis.Pitch = ReadNumber(settings, "pitch", 0.5, 2.0);
        synthesis.PitchRange = ReadOptionalAcssNumber(settings, "pitch_range",
            engine.Capabilities.PitchRange);
        synthesis.Stress = ReadOptionalAcssNumber(settings, "stress",
            engine.Capabilities.Stress);
        synthesis.Richness = ReadOptionalAcssNumber(settings, "richness",
            engine.Capabilities.Richness);
        synthesis.Volume = ReadNumber(settings, "volume", 0.0, 1.0);
        if (selectedProtocolVersion == 6)
        {
            OmnivoxParameterSettings.Read(settings, engine);
            if (request["voice_parameters"] != null)
                synthesis.NativePlan = ((IOmnivoxParameterEngine)engine).PrepareParameters(
                    settings, request["voice_parameters"]);
        }
        synthesis.Anchors = selectedProtocolVersion >= AnchorProtocolVersion ?
            ReadAnchors(request, text) : new OmnivoxHelperAnchor[0];
        synthesis.Progressive = selectedProtocolVersion >=
            ProgressiveProtocolVersion && engine.SupportsProgressiveSynthesis;
        synthesis.Worker = new Thread(delegate() { SynthesisWorker(synthesis); });
        synthesis.Worker.Name = "omnivox-" + engineId + "-synthesis";
        synthesis.Worker.IsBackground = true;

        lock (stateLock)
        {
            if (active != null)
            {
                throw Fault("busy",
                    displayName + " permits one active synthesis", true);
            }
            active = synthesis;
        }

        OmnivoxHelperLog.Event("request_accepted",
            "request_id=" + requestId.ToString(CultureInfo.InvariantCulture) +
            " voice=" + voiceId + " text_bytes=" +
            Encoding.UTF8.GetByteCount(text).ToString(
                CultureInfo.InvariantCulture) + " anchors=" +
            synthesis.Anchors.Length.ToString(CultureInfo.InvariantCulture));

        if (selectedProtocolVersion < 6) WriteStarted(synthesis, null);
        try
        {
            synthesis.Worker.Start();
        }
        catch
        {
            lock (stateLock)
            {
                if (Object.ReferenceEquals(active, synthesis))
                {
                    active = null;
                }
            }
            throw;
        }
    }

    private void WriteStarted(ActiveSynthesis synthesis, Dictionary<string, object> application)
    {
        lock (stateLock)
        {
            if (synthesis.Started) throw new InvalidOperationException("duplicate synthesis start");
            Dictionary<string, object> started = Response(synthesis.RequestId, "synthesis_started");
            started["format"] = OmnivoxParameterWire.Map("sample_rate", engine.SampleRate,
                "channels", engine.Channels, "sample_format", "pcm_s16_le");
            started["actual_voice_id"] = synthesis.VoiceId;
            if (selectedProtocolVersion == 6) started["native_application"] = application;
            if (!WriteSynthesisFrame(synthesis, started, false))
                throw new OperationCanceledException("synthesis retired before application");
            synthesis.Started = true;
        }
    }

    private void SynthesisWorker(ActiveSynthesis synthesis)
    {
        Stopwatch elapsed = Stopwatch.StartNew();
        string request = "request_id=" + synthesis.RequestId.ToString(
            CultureInfo.InvariantCulture);
        try
        {
            OmnivoxHelperLog.Event("native_synthesis_started", request);
            if (synthesis.Cancelled)
            {
                WriteSynthesisFrame(synthesis,
                    Response(synthesis.RequestId, "synthesis_cancelled"), true);
                return;
            }
            ProgressiveWireSink progressiveSink = synthesis.Progressive ?
                new ProgressiveWireSink(this, synthesis) : null;
            OmnivoxCaptureResult result;
            if (synthesis.NativePlan != null)
            {
                result = synthesis.NativePlan.Synthesize(synthesis.Text, synthesis.Anchors,
                    delegate() { return synthesis.Cancelled; }, progressiveSink,
                    delegate(Dictionary<string, object> application) { WriteStarted(synthesis, application); });
            }
            else
            {
                if (selectedProtocolVersion == 6) WriteStarted(synthesis, null);
                result = engine.Synthesize(synthesis.Text,
                synthesis.VoiceId, synthesis.Rate, synthesis.Pitch,
                synthesis.PitchRange, synthesis.Stress, synthesis.Richness,
                synthesis.Volume, synthesis.Anchors,
                delegate() { return synthesis.Cancelled; }, progressiveSink);
            }
            if (!synthesis.Started && !synthesis.Cancelled)
                throw new InvalidOperationException("native engine omitted application receipt");
            if (result == null)
            {
                throw new InvalidOperationException(
                    "native engine returned no synthesis result");
            }
            if (progressiveSink != null)
            {
                ulong progressiveFrames = progressiveSink.Complete();
                OmnivoxHelperLog.Event("native_synthesis_completed",
                    request + " frames=" + progressiveFrames.ToString(
                        CultureInfo.InvariantCulture) + " markers=" +
                    progressiveSink.MarkerCount.ToString(
                        CultureInfo.InvariantCulture) + " elapsed_ms=" +
                    elapsed.ElapsedMilliseconds.ToString(
                        CultureInfo.InvariantCulture));
                if (synthesis.Cancelled)
                {
                    WriteSynthesisFrame(synthesis,
                        Response(synthesis.RequestId, "synthesis_cancelled"), true);
                    return;
                }
                Dictionary<string, object> progressiveCompleted = Response(
                    synthesis.RequestId, "synthesis_completed");
                progressiveCompleted["frame_count"] = progressiveFrames;
                if (!WriteSynthesisFrame(synthesis, progressiveCompleted, true))
                {
                    return;
                }
                OmnivoxHelperLog.Event("request_completed",
                    request + " elapsed_ms=" +
                    elapsed.ElapsedMilliseconds.ToString(
                        CultureInfo.InvariantCulture));
                return;
            }
            byte[] audio = result.Audio;
            OmnivoxHelperMarker[] markers = result.Markers;
            int frameBytes = checked(engine.Channels * 2);
            if (audio == null || audio.Length > MaximumAudioBytes ||
                audio.Length % frameBytes != 0)
            {
                throw new InvalidOperationException(
                    "native engine returned invalid or oversized PCM");
            }
            ulong frameCount = (ulong)(audio.Length / frameBytes);
            ValidateMarkers(markers, frameCount, synthesis.Text,
                synthesis.Anchors);
            OmnivoxHelperLog.Event("native_synthesis_completed",
                request + " frames=" + frameCount.ToString(
                    CultureInfo.InvariantCulture) + " markers=" +
                markers.Length.ToString(CultureInfo.InvariantCulture) +
                " elapsed_ms=" + elapsed.ElapsedMilliseconds.ToString(
                    CultureInfo.InvariantCulture));
            if (synthesis.Cancelled)
            {
                WriteSynthesisFrame(synthesis,
                    Response(synthesis.RequestId, "synthesis_cancelled"), true);
                return;
            }

            int maximumChunk = MaximumAudioChunkBytes -
                (MaximumAudioChunkBytes % frameBytes);
            uint sequence = 0;
            for (int offset = 0; offset < audio.Length; offset += maximumChunk)
            {
                int count = Math.Min(maximumChunk, audio.Length - offset);
                Dictionary<string, object> response = Response(
                    synthesis.RequestId, "audio_chunk");
                Dictionary<string, object> chunk =
                    new Dictionary<string, object>();
                chunk["sequence"] = sequence++;
                chunk["data_base64"] = Convert.ToBase64String(audio,
                    offset, count);
                response["chunk"] = chunk;
                WriteSynthesisFrame(synthesis, response, false);
            }
            if (markers.Length > 0)
            {
                WriteMarkers(synthesis, markers);
            }
            Dictionary<string, object> completed = Response(
                synthesis.RequestId, "synthesis_completed");
            completed["frame_count"] = frameCount;
            if (!WriteSynthesisFrame(synthesis, completed, true))
            {
                return;
            }
            OmnivoxHelperLog.Event("request_completed",
                request + " elapsed_ms=" + elapsed.ElapsedMilliseconds.ToString(
                    CultureInfo.InvariantCulture));
        }
        catch (Exception error)
        {
            OmnivoxHelperLog.Event("request_failed",
                request + " elapsed_ms=" + elapsed.ElapsedMilliseconds.ToString(
                    CultureInfo.InvariantCulture) + " error=\"" +
                OmnivoxHelperLog.ExceptionDetails(error) + "\"");
            WriteSynthesisFrame(synthesis,
                ErrorResponse(synthesis.RequestId, "synthesis_failed",
                    BoundedMessage(error), true), true);
        }
        finally
        {
            lock (stateLock)
            {
                if (Object.ReferenceEquals(active, synthesis))
                {
                    active = null;
                }
            }
        }
    }

    private static void ValidateMarkers(OmnivoxHelperMarker[] markers,
        ulong frameCount, string text, OmnivoxHelperAnchor[] anchors)
    {
        if (markers == null || markers.Length > MaximumMarkers)
        {
            throw new InvalidOperationException(
                "native engine returned invalid or too many markers");
        }
        ulong textBytes = (ulong)Encoding.UTF8.GetByteCount(text);
        HashSet<string> requestedAnchors = new HashSet<string>(
            StringComparer.Ordinal);
        foreach (OmnivoxHelperAnchor anchor in anchors)
        {
            requestedAnchors.Add(anchor.Id);
        }
        HashSet<string> resolvedAnchors = new HashSet<string>(
            StringComparer.Ordinal);
        foreach (OmnivoxHelperMarker marker in markers)
        {
            if (marker == null || marker.FrameOffset > frameCount ||
                (marker.Kind != "word" && marker.Kind != "sentence" &&
                 marker.Kind != "phoneme" && marker.Kind != "native_index" &&
                 marker.Kind != "requested_anchor") ||
                marker.TextStart.HasValue != marker.TextLength.HasValue ||
                (marker.Value != null &&
                 Encoding.UTF8.GetByteCount(marker.Value) >
                    MaximumStringLength) ||
                (marker.Resolution != null &&
                 (marker.Kind != "requested_anchor" ||
                  (marker.Resolution != "exact" &&
                   marker.Resolution != "word_boundary" &&
                   marker.Resolution != "span_boundary" &&
                   marker.Resolution != "omitted"))))
            {
                throw new InvalidOperationException(
                    "native engine returned an invalid marker");
            }
            if (marker.Kind == "requested_anchor" &&
                (marker.Value == null ||
                 !requestedAnchors.Contains(marker.Value) ||
                 !resolvedAnchors.Add(marker.Value)))
            {
                throw new InvalidOperationException(
                    "native engine returned an unknown or duplicate anchor");
            }
            if (marker.TextStart.HasValue &&
                (ulong)marker.TextStart.Value + marker.TextLength.Value >
                    textBytes)
            {
                throw new InvalidOperationException(
                    "native engine marker exceeds the synthesis text");
            }
        }
    }

    private void WriteMarkers(ActiveSynthesis synthesis,
        OmnivoxHelperMarker[] markers)
    {
        object[] values = new object[markers.Length];
        for (int index = 0; index < markers.Length; ++index)
        {
            OmnivoxHelperMarker marker = markers[index];
            Dictionary<string, object> value =
                new Dictionary<string, object>();
            value["kind"] = marker.Kind;
            value["frame_offset"] = marker.FrameOffset;
            if (marker.TextStart.HasValue)
            {
                value["text_start"] = marker.TextStart.Value;
                value["text_length"] = marker.TextLength.Value;
            }
            if (marker.Value != null)
            {
                value["value"] = marker.Value;
            }
            if (marker.Resolution != null)
            {
                value["resolution"] = marker.Resolution;
            }
            values[index] = value;
        }
        Dictionary<string, object> response = Response(synthesis.RequestId,
            "markers");
        response["markers"] = values;
        WriteSynthesisFrame(synthesis, response, false);
    }

    private static OmnivoxHelperAnchor[] ReadAnchors(
        IDictionary<string, object> request, string text)
    {
        object raw = Required(request, "anchors");
        IEnumerable values = raw as IEnumerable;
        if (values == null || raw is string)
        {
            throw Fault("invalid_parameter", "anchors must be an array", false);
        }

        HashSet<uint> boundaries = new HashSet<uint>();
        uint byteOffset = 0;
        boundaries.Add(byteOffset);
        for (int position = 0; position < text.Length;)
        {
            int length = Char.IsHighSurrogate(text[position]) &&
                position + 1 < text.Length &&
                Char.IsLowSurrogate(text[position + 1]) ? 2 : 1;
            byteOffset = checked(byteOffset +
                (uint)Encoding.UTF8.GetByteCount(
                    text.Substring(position, length)));
            boundaries.Add(byteOffset);
            position += length;
        }

        List<OmnivoxHelperAnchor> anchors =
            new List<OmnivoxHelperAnchor>();
        HashSet<string> identifiers = new HashSet<string>(
            StringComparer.Ordinal);
        foreach (object rawAnchor in values)
        {
            IDictionary<string, object> value = rawAnchor as
                IDictionary<string, object>;
            if (value == null)
            {
                throw Fault("invalid_parameter",
                    "each anchor must be an object", false);
            }
            RequireFields(value, "id", "text_offset", "affinity");
            string id = ReadString(value, "id", false);
            uint textOffset = ReadNonnegativeUInt(value, "text_offset");
            string affinity = ReadString(value, "affinity", false);
            if (Encoding.UTF8.GetByteCount(id) > MaximumAnchorIdBytes ||
                !identifiers.Add(id) || !boundaries.Contains(textOffset) ||
                (affinity != "before" && affinity != "after"))
            {
                throw Fault("invalid_parameter",
                    "anchor ID, text offset, or affinity is invalid", false);
            }
            anchors.Add(new OmnivoxHelperAnchor(id, textOffset, affinity));
            if (anchors.Count > MaximumMarkers)
            {
                throw Fault("payload_too_large",
                    "too many requested anchors", false);
            }
        }
        return anchors.ToArray();
    }

    private void HandleCancel(ulong requestId,
        IDictionary<string, object> request)
    {
        RequireFields(request, "protocol_version", "request_id", "type",
            "target_request_id");
        ulong targetRequestId = ReadUnsigned(request, "target_request_id");
        if (targetRequestId == requestId)
        {
            throw Fault("invalid_request",
                "cancel request cannot target itself", false);
        }

        ActiveSynthesis synthesis;
        lock (stateLock)
        {
            synthesis = active;
            if (synthesis == null || synthesis.RequestId != targetRequestId)
            {
                throw Fault("invalid_request",
                    "target synthesis is not active", false);
            }
            synthesis.Cancelled = true;
            Dictionary<string, object> response = Response(requestId,
                "cancel_accepted");
            response["target_request_id"] = targetRequestId;
            WriteFrame(response);
        }
        OmnivoxHelperLog.Event("cancel_requested",
            "request_id=" + requestId.ToString(CultureInfo.InvariantCulture) +
            " target_request_id=" + targetRequestId.ToString(
                CultureInfo.InvariantCulture));
        try
        {
            engine.Stop();
        }
        catch (Exception error)
        {
            // Cancellation is already accepted. Keep suppressing output and
            // leave completion to the worker (or the parent's watchdog),
            // rather than send a second response for the cancel request.
            OmnivoxHelperLog.Event("native_stop_failed",
                "target_request_id=" + targetRequestId.ToString(
                    CultureInfo.InvariantCulture) + " error=\"" +
                OmnivoxHelperLog.ExceptionDetails(error) + "\"");
        }
    }

    private void StopAndJoinActive()
    {
        ActiveSynthesis synthesis;
        lock (stateLock)
        {
            synthesis = active;
            if (synthesis != null)
            {
                synthesis.Cancelled = true;
            }
        }
        if (synthesis == null)
        {
            return;
        }
        engine.Stop();
        bool joined = synthesis.Worker.Join(TimeSpan.FromSeconds(10));
        OmnivoxHelperLog.Event("shutdown_join",
            "request_id=" + synthesis.RequestId.ToString(
                CultureInfo.InvariantCulture) + " joined=" +
            (joined ? "true" : "false"));
    }

    private void WriteDescriptor(ulong requestId)
    {
        if (engine == null)
        {
            WriteError(requestId, "not_available",
                runtimeUnavailableReason, false);
            return;
        }
        Dictionary<string, object> descriptor =
            new Dictionary<string, object>();
        descriptor["id"] = engine.EngineId;
        descriptor["display_name"] = engine.DisplayName;
        descriptor["version"] = engine.Version;
        descriptor["availability"] = Status("available");
        descriptor["health"] = Status("healthy");

        OmnivoxHelperCapabilities advertised = engine.Capabilities;
        Dictionary<string, object> capabilities =
            new Dictionary<string, object>();
        Dictionary<string, object> acss = new Dictionary<string, object>();
        acss["rate"] = advertised.Rate;
        acss["average_pitch"] = advertised.AveragePitch;
        acss["pitch_range"] = advertised.PitchRange;
        acss["stress"] = advertised.Stress;
        acss["richness"] = advertised.Richness;
        acss["volume"] = advertised.Volume;
        capabilities["acss"] = acss;
        capabilities["audio_output"] = selectedProtocolVersion >=
            ProgressiveProtocolVersion && engine.SupportsProgressiveSynthesis ?
            "streaming_pcm" : "buffered_pcm";
        capabilities["cancellation"] = "synthesis_and_playback";
        Dictionary<string, object> concurrency =
            new Dictionary<string, object>();
        concurrency["mode"] = "serialized";
        capabilities["concurrency"] = concurrency;
        Dictionary<string, object> markers =
            new Dictionary<string, object>();
        markers["word"] = advertised.WordMarkers;
        markers["sentence"] = advertised.SentenceMarkers;
        markers["phoneme"] = advertised.PhonemeMarkers;
        markers["native_index"] = advertised.NativeIndexMarkers;
        if (selectedProtocolVersion >= AnchorProtocolVersion)
        {
            markers["requested_anchors"] =
                !String.IsNullOrEmpty(advertised.RequestedAnchors) ?
                advertised.RequestedAnchors : "none";
        }
        capabilities["markers"] = markers;
        capabilities["language_switching"] = advertised.LanguageSwitching;
        capabilities["text_repertoire"] =
            !String.IsNullOrEmpty(advertised.TextRepertoire) ?
            advertised.TextRepertoire : "unknown";
        capabilities["native_extensions"] = new object[0];
        descriptor["capabilities"] = capabilities;

        object[] voices = new object[engine.Voices.Length];
        for (int index = 0; index < engine.Voices.Length; ++index)
        {
            OmnivoxHelperVoice voice = engine.Voices[index];
            Dictionary<string, object> item =
                new Dictionary<string, object>();
            Dictionary<string, object> id = new Dictionary<string, object>();
            id["engine_id"] = engine.EngineId;
            id["voice_id"] = voice.Id;
            item["id"] = id;
            item["display_name"] = voice.Name;
            item["language"] = voice.Language;
            item["gender"] = voice.Gender;
            item["quality"] = "compact";
            item["availability"] = Status("available");
            voices[index] = item;
        }
        descriptor["voices"] = voices;
        descriptor["default_voice_id"] = engine.DefaultVoiceId;

        Dictionary<string, object> response = Response(requestId,
            "descriptor");
        response["descriptor"] = descriptor;
        WriteFrame(response);
    }

    private bool HasVoice(string voiceId)
    {
        foreach (OmnivoxHelperVoice voice in engine.Voices)
        {
            if (voice.Id == voiceId)
            {
                return true;
            }
        }
        return false;
    }

    private static Dictionary<string, object> Status(string status)
    {
        Dictionary<string, object> value = new Dictionary<string, object>();
        value["status"] = status;
        return value;
    }

    private Dictionary<string, object> Response(ulong requestId,
        string type)
    {
        Dictionary<string, object> response =
            new Dictionary<string, object>();
        response["protocol_version"] = selectedProtocolVersion == 0 ?
            SupportedProtocolVersion : selectedProtocolVersion;
        response["request_id"] = requestId;
        response["type"] = type;
        return response;
    }

    private void WriteSimple(ulong requestId, string type)
    {
        WriteFrame(Response(requestId, type));
    }

    private void WriteError(ulong? requestId, string code, string message,
        bool retryable)
    {
        WriteFrame(ErrorResponse(requestId, code, message, retryable));
    }

    private Dictionary<string, object> ErrorResponse(ulong? requestId,
        string code, string message, bool retryable)
    {
        Dictionary<string, object> response =
            new Dictionary<string, object>();
        response["protocol_version"] = selectedProtocolVersion == 0 ?
            SupportedProtocolVersion : selectedProtocolVersion;
        response["request_id"] = requestId.HasValue ?
            (object)requestId.Value : null;
        response["type"] = "error";
        response["code"] = code;
        response["message"] = message;
        response["retryable"] = retryable;
        return response;
    }

    private bool WriteSynthesisFrame(ActiveSynthesis synthesis,
        Dictionary<string, object> response, bool terminal)
    {
        lock (stateLock)
        {
            if (!Object.ReferenceEquals(active, synthesis))
            {
                return false;
            }
            if (synthesis.Cancelled)
            {
                if (!terminal)
                {
                    throw new OperationCanceledException(
                        "synthesis output was cancelled");
                }
                response = Response(synthesis.RequestId, "synthesis_cancelled");
            }
            WriteFrame(response);
            if (terminal)
            {
                // A cancel arriving after this terminal must not be accepted,
                // even if the worker has not reached its finally block yet.
                active = null;
            }
            return !synthesis.Cancelled;
        }
    }

    private void WriteFrame(Dictionary<string, object> response)
    {
        string line = json.Serialize(response);
        if (Encoding.UTF8.GetByteCount(line) > MaximumFrameBytes)
        {
            throw new InvalidOperationException(
                "helper response exceeds the 1 MiB frame limit");
        }
        lock (outputLock)
        {
            output.WriteLine(line);
        }
    }

    // JavaScriptSerializer overwrites duplicate members and accepts some
    // JavaScript syntax that is not JSON. Check the bounded wire text before
    // materializing a dictionary or trusting a request ID.
    private sealed class JsonKeyCheck
    {
        private readonly string text;
        private readonly JavaScriptSerializer serializer;
        private int position;
        private readonly bool parameterVersion;

        internal JsonKeyCheck(string text, JavaScriptSerializer serializer, bool parameterVersion = false)
        {
            this.text = text;
            this.serializer = serializer;
            this.parameterVersion = parameterVersion;
        }

        internal void Validate()
        {
            Value(0);
            Space();
            if (position != text.Length) Invalid();
        }

        private static void Invalid()
        {
            throw Fault("invalid_request", "invalid or duplicate-key helper JSON", false);
        }

        private void Space()
        {
            while (position < text.Length &&
                (text[position] == ' ' || text[position] == '\t' ||
                 text[position] == '\r' || text[position] == '\n')) position++;
        }

        private bool Take(char value)
        {
            Space();
            if (position >= text.Length || text[position] != value) return false;
            position++;
            return true;
        }

        private void Require(char value)
        {
            if (!Take(value)) Invalid();
        }

        private string String(bool key)
        {
            Space();
            int start = position;
            Require('"');
            while (position < text.Length)
            {
                char value = text[position++];
                if (value == '"')
                    return key ? serializer.Deserialize<string>(text.Substring(start, position - start)) : null;
                if (value < 0x20) Invalid();
                if (value != '\\') continue;
                if (position == text.Length) Invalid();
                char escaped = text[position++];
                if (escaped == 'u')
                {
                    for (int i = 0; i < 4; i++)
                    {
                        if (position == text.Length) Invalid();
                        char digit = text[position++];
                        if (!(digit >= '0' && digit <= '9') &&
                            !(digit >= 'a' && digit <= 'f') &&
                            !(digit >= 'A' && digit <= 'F')) Invalid();
                    }
                }
                else if ("\"\\/bfnrt".IndexOf(escaped) < 0) Invalid();
            }
            Invalid();
            return null;
        }

        private void Digits()
        {
            int start = position;
            while (position < text.Length && text[position] >= '0' && text[position] <= '9') position++;
            if (position == start) Invalid();
        }

        private void Number()
        {
            if (position < text.Length && text[position] == '-') position++;
            if (position < text.Length && text[position] == '0') position++;
            else Digits();
            if (position < text.Length && text[position] == '.') { position++; Digits(); }
            if (position < text.Length && (text[position] == 'e' || text[position] == 'E'))
            {
                position++;
                if (position < text.Length && (text[position] == '+' || text[position] == '-')) position++;
                Digits();
            }
        }

        private void Value(int depth, string owner = null, bool unsignedInteger = false)
        {
            if (depth > 32) Invalid();
            Space();
            if (position == text.Length) Invalid();
            char value = text[position];
            if (unsignedInteger)
            {
                if (value < '0' || value > '9') Invalid();
                if (value == '0') position++; else Digits();
                return;
            }
            if (value == '{')
            {
                position++;
                HashSet<string> keys = new HashSet<string>(StringComparer.Ordinal);
                if (Take('}')) return;
                do
                {
                    string key = String(true);
                    if (!keys.Add(key)) Invalid();
                    Require(':');
                    bool integer = parameterVersion && (
                        (depth == 0 && (key == "protocol_version" || key == "request_id" || key == "target_request_id")) ||
                        (owner == "expected_identity" && key == "runtime_generation") ||
                        (owner == "anchors" && key == "text_offset"));
                    Value(depth + 1, key, integer);
                    if (Take('}')) return;
                } while (Take(','));
                Invalid();
            }
            else if (value == '[')
            {
                position++;
                if (Take(']')) return;
                do
                {
                    Value(depth + 1, owner, parameterVersion && owner == "supported_protocol_versions");
                    if (Take(']')) return;
                } while (Take(','));
                Invalid();
            }
            else if (value == '"') String(false);
            else if (value == 't' || value == 'f' || value == 'n')
            {
                string literal = value == 't' ? "true" : value == 'f' ? "false" : "null";
                if (position + literal.Length > text.Length ||
                    System.String.CompareOrdinal(text, position, literal, 0, literal.Length) != 0) Invalid();
                position += literal.Length;
            }
            else Number();
        }
    }

    private static object Required(IDictionary<string, object> values,
        string field)
    {
        object value;
        if (!values.TryGetValue(field, out value))
        {
            throw Fault("invalid_request",
                "missing required field: " + field, false);
        }
        return value;
    }

    private static string ReadString(IDictionary<string, object> values,
        string field, bool allowEmpty)
    {
        string value = Required(values, field) as string;
        if (value == null || (!allowEmpty && value.Length == 0) ||
            !IsWellFormedUnicode(value) ||
            Encoding.UTF8.GetByteCount(value) > MaximumStringLength)
        {
            throw Fault("invalid_request", "invalid string field: " + field,
                false);
        }
        return value;
    }

    private static string ReadText(IDictionary<string, object> values)
    {
        string value = Required(values, "text") as string;
        if (value == null || !IsWellFormedUnicode(value))
        {
            throw Fault("invalid_request", "invalid string field: text",
                false);
        }
        return value;
    }

    private static bool IsWellFormedUnicode(string value)
    {
        for (int index = 0; index < value.Length; ++index)
        {
            if (Char.IsHighSurrogate(value[index]))
            {
                if (index + 1 >= value.Length ||
                    !Char.IsLowSurrogate(value[index + 1]))
                {
                    return false;
                }
                ++index;
            }
            else if (Char.IsLowSurrogate(value[index]))
            {
                return false;
            }
        }
        return true;
    }

    private static int ReadInteger(IDictionary<string, object> values,
        string field)
    {
        return ConvertInteger(Required(values, field), field);
    }

    private static int ConvertInteger(object value, string field)
    {
        try
        {
            decimal number = Convert.ToDecimal(value,
                CultureInfo.InvariantCulture);
            if (Decimal.Truncate(number) != number || number < Int32.MinValue ||
                number > Int32.MaxValue)
            {
                throw new OverflowException();
            }
            return Decimal.ToInt32(number);
        }
        catch
        {
            throw Fault("invalid_request", "invalid integer field: " + field,
                false);
        }
    }

    private static ulong ReadUnsigned(IDictionary<string, object> values,
        string field)
    {
        object value = Required(values, field);
        try
        {
            decimal number = Convert.ToDecimal(value,
                CultureInfo.InvariantCulture);
            if (Decimal.Truncate(number) != number || number <= 0 ||
                number > UInt64.MaxValue)
            {
                throw new OverflowException();
            }
            return Decimal.ToUInt64(number);
        }
        catch
        {
            throw Fault("invalid_request",
                "invalid positive integer field: " + field, false);
        }
    }

    private static uint ReadNonnegativeUInt(
        IDictionary<string, object> values, string field)
    {
        object value = Required(values, field);
        try
        {
            decimal number = Convert.ToDecimal(value,
                CultureInfo.InvariantCulture);
            if (Decimal.Truncate(number) != number || number < 0 ||
                number > UInt32.MaxValue)
            {
                throw new OverflowException();
            }
            return Decimal.ToUInt32(number);
        }
        catch
        {
            throw Fault("invalid_request",
                "invalid nonnegative integer field: " + field, false);
        }
    }

    private static double ReadNumber(IDictionary<string, object> values,
        string field, double minimum, double maximum)
    {
        try
        {
            double value = Convert.ToDouble(Required(values, field),
                CultureInfo.InvariantCulture);
            if (Double.IsNaN(value) || Double.IsInfinity(value) ||
                value < minimum || value > maximum)
            {
                throw new OverflowException();
            }
            return value;
        }
        catch (ProtocolException)
        {
            throw;
        }
        catch
        {
            throw Fault("invalid_parameter",
                "invalid numeric field: " + field, false);
        }
    }

    private double? ReadOptionalAcssNumber(
        IDictionary<string, object> values, string field, bool supported)
    {
        object raw;
        if (!values.TryGetValue(field, out raw) || raw == null)
        {
            return null;
        }
        if (!supported)
        {
            throw Fault("invalid_parameter",
                displayName + " does not support ACSS " + field,
                false);
        }
        return ReadNumber(values, field, 0.0, 1.0);
    }

    private static void RequireFields(IDictionary<string, object> values,
        params string[] allowed)
    {
        HashSet<string> names = new HashSet<string>(allowed,
            StringComparer.Ordinal);
        foreach (string name in values.Keys)
        {
            if (!names.Contains(name))
            {
                throw Fault("invalid_request",
                    "unknown helper request field: " + name, false);
            }
        }
    }

    private static string BoundedMessage(Exception error)
    {
        string message = error.Message;
        if (String.IsNullOrEmpty(message))
        {
            message = error.GetType().Name;
        }
        if (message.Length > MaximumStringLength)
        {
            message = message.Substring(0, MaximumStringLength);
        }
        return message;
    }

    private static ProtocolException Fault(string code, string message,
        bool retryable)
    {
        return new ProtocolException(code, message, retryable);
    }
}
